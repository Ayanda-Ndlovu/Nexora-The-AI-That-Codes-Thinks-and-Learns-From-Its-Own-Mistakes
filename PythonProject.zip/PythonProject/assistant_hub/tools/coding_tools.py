# assistant_hub/tools/coding_tools.py
from typing import Dict, Any
import io
import contextlib
import traceback
from assistant_hub.toolsIf.toolsIF import ITool


class CodeGeneratorTool(ITool):
    def run(self, task: str, requirements: str = "", research: Dict[str, Any] = None, **kwargs) -> Dict[str, Any]:
        """
        Generate code based on requirements and research findings
        """
        try:
            # Enhanced prompt using research context
            research_context = ""
            if research and 'analysis' in research:
                research_context = f"\nResearch Context: {research['analysis'].get('summary', 'No research available')}"

            code_prompt = f"""
            Generate Python code for the following task:

            Task: {task}
            Requirements: {requirements}
            {research_context}

            Provide clean, working code with proper error handling.
            """

            # In a real implementation, this would call an LLM
            # For now, return a template response
            example_code = f'''# Code for: {task}
def main():
    print("Hello! This is generated code for: {task}")
    # Add your implementation here

if __name__ == "__main__":
    main()'''

            return {
                "code": example_code,
                "language": "python",
                "task": task,
                "success": True
            }

        except Exception as e:
            return {
                "error": f"Code generation failed: {str(e)}",
                "success": False
            }

    def get_description(self) -> str:
        return "Generate code based on requirements and research findings"


class CodeExecutionTool(ITool):
    def run(self, code_input: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Executes Python code snippets safely and returns output
        """
        try:
            code = code_input.get("code", "") if isinstance(code_input, dict) else str(code_input)

            if not code.strip():
                return {"error": "No code provided", "success": False}

            output_buffer = io.StringIO()
            error_buffer = io.StringIO()

            try:
                with contextlib.redirect_stdout(output_buffer), contextlib.redirect_stderr(error_buffer):
                    # Create a safe execution environment
                    safe_globals = {
                        '__builtins__': {
                            'print': print,
                            'len': len,
                            'range': range,
                            'str': str,
                            'int': int,
                            'float': float,
                            'list': list,
                            'dict': dict,
                            'set': set,
                            'tuple': tuple
                        }
                    }
                    exec(code, safe_globals, {})

                stdout_output = output_buffer.getvalue()
                stderr_output = error_buffer.getvalue()

                result = {
                    "success": True,
                    "stdout": stdout_output,
                    "stderr": stderr_output,
                    "output": stdout_output if stdout_output else "Code executed successfully (no output)"
                }

            except Exception as e:
                error_traceback = traceback.format_exc()
                result = {
                    "success": False,
                    "error": str(e),
                    "traceback": error_traceback,
                    "stderr": error_buffer.getvalue()
                }

            return result

        except Exception as e:
            return {
                "error": f"Code execution setup failed: {str(e)}",
                "success": False
            }

    def get_description(self) -> str:
        return "Executes Python code snippets safely and returns output"


class CodeValidatorTool(ITool):
    def run(self, code: Dict[str, Any], requirements: str = "") -> Dict[str, Any]:
        """
        Validates generated code for basic syntax and structure
        """
        try:
            code_content = code.get('code', '') if isinstance(code, dict) else str(code)
            issues = []

            if not code_content.strip():
                issues.append("Validation failed: Generated code is empty.")

            # Basic Python syntax check
            try:
                compile(code_content, '<string>', 'exec')
                syntax_valid = True
            except SyntaxError as e:
                syntax_valid = False
                issues.append(f"Syntax error: {e}")

            # Basic code quality checks
            lines = code_content.split('\n')
            if len(lines) > 50:
                issues.append("Code might be too long - consider breaking into functions")

            if 'TODO' in code_content or 'FIXME' in code_content:
                issues.append("Code contains TODO/FIXME comments")

            # Check for basic structure
            if 'def ' not in code_content and 'class ' not in code_content:
                issues.append("No functions or classes defined - consider adding structure")

            return {
                "valid": len(issues) == 0,
                "issues": issues,
                "syntax_valid": syntax_valid,
                "code_length": len(code_content),
                "line_count": len(lines)
            }

        except Exception as e:
            return {
                "valid": False,
                "issues": [f"Validation tool error: {str(e)}"],
                "syntax_valid": False
            }

    def get_description(self) -> str:
        return "Validates generated code for correctness, style, and possible errors"