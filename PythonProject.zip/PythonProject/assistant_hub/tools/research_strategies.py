# assistant_hub/tools/research_strategies.py - NEW FILE
from typing import Dict, Any, List
from assistant_hub.core.logging_config import logger


class ResearchStrategy:
    """Coordinates web search, scraping, analysis, and summarization."""

    def __init__(self, tool_factory):
        self.tool_factory = tool_factory

    def execute(self, topic: str, max_search_results: int = 3) -> Dict[str, Any]:
        """Execute comprehensive research strategy"""
        try:
            scraped_contents = {}

            # Step 1: Search
            search_tool = self.tool_factory.create_tool("web_search")
            search_results = search_tool.run(query=topic, max_results=max_search_results)

            # Step 2: Scrape
            scraper_tool = self.tool_factory.create_tool("web_scraper")
            for result in search_results.get("results", []):
                url = result.get("url")
                if url and url.startswith("http"):
                    try:
                        scrape_result = scraper_tool.run(url=url)
                        content = scrape_result.get("content", "")
                        if content:
                            scraped_contents[url] = {
                                "url": url,
                                "title": result.get("title", "Unknown"),
                                "content": content[:1000]  # Limit content length
                            }
                    except Exception as e:
                        logger.warning(f"Failed to scrape {url}: {e}")

            # Step 3: Analyze combined content
            combined_text = "\n\n".join(
                [f"From {item['title']}:\n{item['content']}" for item in scraped_contents.values()]
            )

            analysis = {}
            if combined_text:
                analyzer_tool = self.tool_factory.create_tool("content_analyzer")
                analysis = analyzer_tool.run(content=combined_text)

            # Step 4: Summarize
            summary = {}
            if combined_text:
                summarizer_tool = self.tool_factory.create_tool("summarizer")
                summary = summarizer_tool.run(content=combined_text)

            return {
                "topic": topic,
                "search_results": search_results,
                "scraped_contents": scraped_contents,
                "analysis": analysis,
                "summary": summary,
                "success": True
            }

        except Exception as e:
            logger.error(f"ResearchStrategy failed: {e}")
            return {
                "topic": topic,
                "error": str(e),
                "success": False
            }