# assistant_hub/tools/langchain_tools.py
from typing import Optional, Type, Dict, Any, List
from pydantic import BaseModel, Field
from langchain.tools import BaseTool
from assistant_hub.toolsIf.toolsIF import ITool
from abc import abstractmethod


class CompatibleToolWrapper(BaseTool, ITool):
    """Base class that works with both LangChain and custom ITool interface"""

    @abstractmethod
    def _execute(self, **kwargs) -> Any:
        """ITool-compatible execute method"""
        pass

    def _run(self, **kwargs) -> Any:
        """LangChain _run method"""
        return self._execute(**kwargs)

    def execute(self, **kwargs) -> Any:
        """ITool execute method"""
        return self._execute(**kwargs)

    def get_description(self) -> str:
        """ITool get_description method"""
        return self.description


class WebSearchToolWrapper(CompatibleToolWrapper):
    name: str = "web_search"
    description: str = "Performs web searches using various search engines"

    class InputSchema(BaseModel):
        query: str = Field(description="Search query string")
        max_results: int = Field(default=5, description="Maximum number of results to return")
        search_engine: str = Field(default="duckduckgo", description="Search engine to use")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, query: str, max_results: int = 5, search_engine: str = "duckduckgo") -> Dict[str, Any]:
        from assistant_hub.tools.research_tools import WebSearchTool
        tool = WebSearchTool()
        return tool.execute(query=query, max_results=max_results, search_engine=search_engine)


class ContentAnalyzerToolWrapper(CompatibleToolWrapper):
    name: str = "content_analyzer"
    description: str = "Analyzes text content and extracts key insights"

    class InputSchema(BaseModel):
        content: Dict[str, Any] = Field(description="Content to analyze")
        analysis_type: str = Field(default="summary", description="Type of analysis to perform")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, content: Dict[str, Any], analysis_type: str = "summary") -> Dict[str, Any]:
        from assistant_hub.tools.research_tools import ContentAnalyzerTool
        tool = ContentAnalyzerTool()
        return tool.execute(content=content, analysis_type=analysis_type)


class ResearchSummarizerToolWrapper(CompatibleToolWrapper):
    name: str = "research_summarizer"
    description: str = "Synthesizes research findings from multiple sources"

    class InputSchema(BaseModel):
        research_data: Dict[str, Any] = Field(description="Research data to summarize")
        output_format: str = Field(default="text", description="Output format")
        include_visualizations: bool = Field(default=False, description="Include charts and tables")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, research_data: Dict[str, Any], output_format: str = "text",
                 include_visualizations: bool = False) -> Dict[str, Any]:
        from assistant_hub.tools.research_tools import ResearchSummarizerTool
        tool = ResearchSummarizerTool()
        return tool.execute(research_data=research_data, output_format=output_format,
                          include_visualizations=include_visualizations)


class CodeGeneratorToolWrapper(CompatibleToolWrapper):
    name: str = "code_generator"
    description: str = "Generate code based on requirements and research findings"

    class InputSchema(BaseModel):
        task: str = Field(description="The coding task to accomplish")
        requirements: str = Field(description="Requirements for the code")
        research: Dict[str, Any] = Field(description="Research findings to inform the code")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, task: str, requirements: str, research: Dict[str, Any]) -> Dict[str, Any]:
        from assistant_hub.tools.coding_tools import CodeGeneratorTool
        tool = CodeGeneratorTool()
        return tool.execute(task=task, requirements=requirements, research=research)


class CodeValidatorToolWrapper(CompatibleToolWrapper):
    name: str = "code_validator"
    description: str = "Validate generated code for correctness, style, and possible errors"

    class InputSchema(BaseModel):
        code: Dict[str, Any] = Field(description="The code to validate")
        requirements: str = Field(description="Requirements to validate against")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, code: Dict[str, Any], requirements: str) -> Dict[str, Any]:
        from assistant_hub.tools.coding_tools import CodeValidatorTool
        tool = CodeValidatorTool()
        return tool.execute(code=code, requirements=requirements)


class WebScraperToolWrapper(CompatibleToolWrapper):
    name: str = "web_scraper"
    description: str = "Scrapes and extracts content from web pages"

    class InputSchema(BaseModel):
        url: str = Field(description="URL to scrape")
        extract_type: str = Field(default="content", description="Type of content to extract")
        css_selector: str = Field(default=None, description="CSS selector for specific elements")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, url: str, extract_type: str = "content", css_selector: str = None) -> Dict[str, Any]:
        from assistant_hub.tools.research_tools import WebScraperTool
        tool = WebScraperTool()
        return tool.execute(url=url, extract_type=extract_type, css_selector=css_selector)


class OutputFormatterToolWrapper(CompatibleToolWrapper):
    name: str = "output_formatter"
    description: str = "Formats content into different output formats (markdown, HTML, text, JSON)"

    class InputSchema(BaseModel):
        content: Any = Field(description="Content to format")
        target_format: str = Field(default="auto", description="Target format: markdown, html, text, json")
        include_visualizations: bool = Field(default=False, description="Whether to include charts")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, content: Any, target_format: str = "auto",
                 include_visualizations: bool = False) -> Dict[str, Any]:
        from assistant_hub.tools.output_formatter import OutputFormatterTool
        tool = OutputFormatterTool()
        return tool.execute(content=content, target_format=target_format,
                          include_visualizations=include_visualizations)


class ChartGeneratorToolWrapper(CompatibleToolWrapper):
    name: str = "chart_generator"
    description: str = "Generates charts and visualizations from data"

    class InputSchema(BaseModel):
        data: Dict[str, Any] = Field(description="Data for chart generation")
        chart_type: str = Field(default="auto", description="Type of chart: bar, line, pie, auto")
        output_format: str = Field(default="markdown", description="Output format")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, data: Dict[str, Any], chart_type: str = "auto",
                 output_format: str = "markdown") -> Dict[str, Any]:
        from assistant_hub.tools.visualization_tools import ChartGeneratorTool
        tool = ChartGeneratorTool()
        return tool.execute(data=data, chart_type=chart_type, output_format=output_format)


class TableProcessorToolWrapper(CompatibleToolWrapper):
    name: str = "table_processor"
    description: str = "Extracts and processes tables from content into various formats"

    class InputSchema(BaseModel):
        content: str = Field(description="Content containing tables")
        table_format: str = Field(default="markdown", description="Output format for tables")
        extraction_method: str = Field(default="auto", description="Extraction method to use")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, content: str, table_format: str = "markdown",
                 extraction_method: str = "auto") -> Dict[str, Any]:
        from assistant_hub.tools.visualization_tools import TableProcessorTool
        tool = TableProcessorTool()
        return tool.execute(content=content, table_format=table_format,
                          extraction_method=extraction_method)

# assistant_hub/tools/langchain_tools.py - ADD MISSING WRAPPER

# Add this class to the existing file
class CodeExecutionToolWrapper(CompatibleToolWrapper):
    name: str = "code_execution"
    description: str = "Executes Python code snippets and returns the output"

    class InputSchema(BaseModel):
        code: str = Field(description="Python code to execute")
        language: str = Field(default="python", description="Programming language")

    args_schema: Optional[Type[BaseModel]] = InputSchema

    def _execute(self, code: str, language: str = "python") -> Dict[str, Any]:
        from assistant_hub.tools.coding_tools import CodeExecutionTool
        tool = CodeExecutionTool()
        return tool.run({"code": code, "language": language})