# assistant_hub/tools/research_tools.py
from assistant_hub.toolsIf.toolsIF import ITool
import requests
from bs4 import BeautifulSoup
import json
from typing import Dict, Any, List
import time
import re


class WebSearchTool(ITool):
    def run(self, query: str, max_results: int = 5, search_engine: str = "duckduckgo") -> Dict[str, Any]:
        try:
            if search_engine == "duckduckgo":
                return self._duckduckgo_search(query, max_results)
            else:
                return self._simulated_search(query, max_results)
        except Exception as e:
            return {"error": f"Search failed: {str(e)}", "results": []}

    def _duckduckgo_search(self, query: str, max_results: int) -> Dict[str, Any]:
        try:
            url = "https://api.duckduckgo.com/"
            params = {'q': query, 'format': 'json', 'no_html': '1', 'skip_disambig': '1'}
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            results = []
            if data.get('AbstractText'):
                results.append({'title': data.get('Heading', 'Abstract'),
                                'url': data.get('AbstractURL', ''),
                                'snippet': data.get('AbstractText', ''),
                                'source': 'duckduckgo'})
            for topic in data.get('RelatedTopics', [])[:max_results-1]:
                if 'FirstURL' in topic and 'Text' in topic:
                    results.append({'title': topic.get('Text', '').split(' - ')[0] if ' - ' in topic.get('Text', '') else 'Related Topic',
                                    'url': topic['FirstURL'],
                                    'snippet': topic.get('Text', ''),
                                    'source': 'duckduckgo'})
            return {"results": results[:max_results], "query": query, "total_results": len(results)}
        except:
            return self._simulated_search(query, max_results)

    def _simulated_search(self, query: str, max_results: int) -> Dict[str, Any]:
        simulated_results = [
            {"title": f"Sample Result {i+1}", "url": f"https://example.com/{i+1}", "snippet": f"Snippet for {query}", "source": "simulated"}
            for i in range(max_results)
        ]
        return {"results": simulated_results, "query": query, "total_results": len(simulated_results)}

    def get_description(self) -> str:
        return "Performs web search and returns top results including titles, URLs, and snippets"


class WebScraperTool(ITool):
    def run(self, url: str, timeout: int = 10) -> Dict[str, Any]:
        try:
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
            for script in soup(["script", "style"]):
                script.decompose()
            text = ' '.join(soup.stripped_strings)
            return {"content": text, "url": url, "success": True}
        except Exception as e:
            return {"content": "", "url": url, "success": False, "error": str(e)}

    def get_description(self) -> str:
        return "Scrapes the main textual content from a given URL"


# In research_tools.py - UPDATE ContentAnalyzerTool
class ContentAnalyzerTool(ITool):
    def run(self, content: Any, analysis_type: str = "comprehensive") -> Dict[str, Any]:  # CHANGED
        try:
            # Handle both string and dict input
            if isinstance(content, dict):
                text = content.get('content', '') if 'content' in content else str(content)
            else:
                text = str(content)

            summary = self._generate_summary(text)
            # ... rest of the method unchanged
            key_points = self._extract_key_points(text)
            facts = self._extract_facts(text)
            sentiment = self._analyze_sentiment(text)
            topics = self._identify_topics(text)

            return {
                "summary": summary,
                "key_points": key_points,
                "facts": facts,
                "sentiment": sentiment,
                "topics": topics,
                "success": True
            }
        except Exception as e:
            return {"error": f"Analysis failed: {str(e)}", "success": False}

    def _generate_summary(self, text: str) -> str:
        sentences = text.split('.')
        if len(sentences) < 3:
            return text
        return '. '.join(sentences[:3]).strip() + '.'

    def _extract_key_points(self, text: str) -> List[str]:
        return [line.strip() for line in text.split('.') if len(line.strip()) > 20][:5]

    def _extract_facts(self, text: str) -> List[str]:
        facts = re.findall(r'\b\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\b', text)
        return facts

    def _analyze_sentiment(self, text: str) -> str:
        if any(word in text.lower() for word in ['good', 'great', 'positive']):
            return "positive"
        elif any(word in text.lower() for word in ['bad', 'negative', 'poor']):
            return "negative"
        return "neutral"

    def _identify_topics(self, text: str) -> List[str]:
        common_words = ['the', 'and', 'of', 'in', 'to', 'a']
        words = [w.lower() for w in re.findall(r'\b\w+\b', text) if w.lower() not in common_words]
        freq = {}
        for w in words:
            freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)
        return [w for w, _ in sorted_words[:5]]

    def get_description(self) -> str:
        return "Analyzes content text to extract summary, key points, facts, sentiment, and topics"


class ResearchSummarizerTool(ITool):
    def run(self, scraped_contents: Dict[str, Dict[str, Any]], output_format: str = "markdown") -> Dict[str, Any]:
        try:
            combined_text = self._combine_research_content(scraped_contents)
            return {"summary": combined_text, "format": output_format, "success": True}
        except Exception as e:
            return {"error": f"Summarization failed: {str(e)}", "success": False}

    def _combine_research_content(self, scraped_contents: Dict[str, Dict[str, Any]]) -> str:
        combined = ""
        for url, data in scraped_contents.items():
            text_content = data.get('content', '')
            combined += f"### Source: {url}\n\n{text_content}\n\n"
        return combined.strip()

    def get_description(self) -> str:
        return "Combines multiple scraped research contents into a single summarized report"

