# agent_monitor.py - For monitoring agent execution
import time
from typing import Dict, Any, List
from datetime import datetime


class AgentMonitor:
    def __init__(self):
        self.metrics = {
            'start_time': time.time(),
            'agent_executions': [],
            'errors': [],
            'performance_metrics': {}
        }

    def log_agent_execution(self, agent_name: str, status: str, execution_time: float,
                            input_data: Dict = None, output_data: Dict = None):
        """Log agent execution details"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'agent': agent_name,
            'status': status,
            'execution_time': execution_time,
            'input_keys': list(input_data.keys()) if input_data else [],
            'output_keys': list(output_data.keys()) if output_data else []
        }

        self.metrics['agent_executions'].append(log_entry)

        # Update performance metrics
        if agent_name not in self.metrics['performance_metrics']:
            self.metrics['performance_metrics'][agent_name] = {
                'execution_count': 0,
                'total_time': 0,
                'success_count': 0,
                'error_count': 0
            }

        metrics = self.metrics['performance_metrics'][agent_name]
        metrics['execution_count'] += 1
        metrics['total_time'] += execution_time

        if status == 'success':
            metrics['success_count'] += 1
        else:
            metrics['error_count'] += 1
            self.metrics['errors'].append({
                'agent': agent_name,
                'error': status,
                'timestamp': log_entry['timestamp']
            })

    def get_agent_performance(self, agent_name: str) -> Dict[str, Any]:
        """Get performance metrics for a specific agent"""
        if agent_name in self.metrics['performance_metrics']:
            metrics = self.metrics['performance_metrics'][agent_name]
            return {
                'agent': agent_name,
                'execution_count': metrics['execution_count'],
                'success_rate': metrics['success_count'] / metrics['execution_count'] * 100,
                'average_time': metrics['total_time'] / metrics['execution_count'],
                'error_count': metrics['error_count']
            }
        return {}

    def generate_report(self) -> Dict[str, Any]:
        """Generate comprehensive execution report"""
        total_time = time.time() - self.metrics['start_time']
        total_executions = len(self.metrics['agent_executions'])

        successful_executions = sum(1 for exec in self.metrics['agent_executions']
                                    if exec['status'] == 'success')

        return {
            'report_generated': datetime.now().isoformat(),
            'total_execution_time': total_time,
            'total_agent_executions': total_executions,
            'successful_executions': successful_executions,
            'success_rate': (successful_executions / total_executions * 100) if total_executions > 0 else 0,
            'agent_performance': self.metrics['performance_metrics'],
            'recent_errors': self.metrics['errors'][-5:] if self.metrics['errors'] else [],
            'execution_timeline': self.metrics['agent_executions'][-10:]  # Last 10 executions
        }