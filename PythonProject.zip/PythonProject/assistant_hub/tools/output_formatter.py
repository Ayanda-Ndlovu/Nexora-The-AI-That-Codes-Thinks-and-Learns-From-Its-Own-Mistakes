# assistant_hub/tools/output_formatter.py - FIXED VERSION

from typing import Dict, Any, List
from assistant_hub.toolsIf.toolsIF import ITool
import re


class OutputFormatterTool(ITool):
    def run(self, content: Any, target_format: str = "auto", **kwargs) -> Dict[str, Any]:
        """
        Flexible output formatting for different content types
        """
        try:
            if target_format == "auto":
                target_format = self._detect_best_format(content)

            formatter_method = getattr(self, f'_format_as_{target_format}', self._format_as_text)
            formatted_content = formatter_method(content, **kwargs)

            return {
                "content": formatted_content,
                "format": target_format,
                "original_type": type(content).__name__,
                "success": True
            }

        except Exception as e:
            return {
                "error": f"Formatting failed: {str(e)}",
                "success": False
            }

    def _detect_best_format(self, content: Any) -> str:
        """Auto-detect the best output format"""
        if isinstance(content, dict) and len(content) > 3:
            return "markdown"
        elif isinstance(content, list) and len(content) > 2:
            return "markdown"
        elif isinstance(content, str) and len(content) > 200:
            return "text"
        else:
            return "text"

    def _format_as_markdown(self, content: Any, **kwargs) -> str:
        """Format content as markdown"""
        if isinstance(content, dict):
            return self._dict_to_markdown(content)
        elif isinstance(content, list):
            return self._list_to_markdown(content)
        elif isinstance(content, str):
            return content  # Already text
        else:
            return f"```\n{str(content)}\n```"

    def _format_as_text(self, content: Any, **kwargs) -> str:
        """Format as clean text"""
        return str(content)

    def _format_as_html(self, content: Any, **kwargs) -> str:
        """Format content as HTML"""
        if isinstance(content, dict):
            return self._dict_to_html(content)
        elif isinstance(content, list):
            return self._list_to_html(content)
        else:
            return f"<pre>{str(content)}</pre>"

    def _format_as_json(self, content: Any, **kwargs) -> str:
        """Format content as JSON"""
        import json
        try:
            return json.dumps(content, indent=2, ensure_ascii=False)
        except:
            return json.dumps(str(content))

    def _dict_to_markdown(self, data: Dict) -> str:
        """Convert dictionary to markdown format"""
        output = ""

        # Create key-value list for small dicts
        if len(data) <= 5:
            for key, value in data.items():
                output += f"**{key}**: {value}\n\n"
        else:
            # Create table for larger dicts
            output = "| Key | Value |\n|-----|-------|\n"
            for key, value in data.items():
                output += f"| {key} | {value} |\n"

        return output

    def _list_to_markdown(self, data: List) -> str:
        """Convert list to markdown"""
        output = ""
        for i, item in enumerate(data, 1):
            output += f"{i}. {item}\n"
        return output

    def _dict_to_html(self, data: Dict) -> str:
        """Convert dictionary to HTML"""
        if len(data) <= 5:
            html = "<dl>"
            for key, value in data.items():
                html += f"<dt><strong>{key}</strong></dt><dd>{value}</dd>"
            html += "</dl>"
        else:
            html = "<table border='1'><tr><th>Key</th><th>Value</th></tr>"
            for key, value in data.items():
                html += f"<tr><td>{key}</td><td>{value}</td></tr>"
            html += "</table>"
        return html

    def _list_to_html(self, data: List) -> str:
        """Convert list to HTML"""
        html = "<ol>"
        for item in data:
            html += f"<li>{item}</li>"
        html += "</ol>"
        return html

    def get_description(self) -> str:
        return "Formats content into different output formats (markdown, HTML, text, JSON)"