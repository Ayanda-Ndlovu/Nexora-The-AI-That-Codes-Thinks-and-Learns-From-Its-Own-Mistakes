# assistant_hub/tools/__init__.py - UPDATED
from .research_tools import WebSearchTool, WebScraperTool, ContentAnalyzerTool, ResearchSummarizerTool
from .coding_tools import CodeGeneratorTool, CodeValidatorTool, CodeExecutionTool
from .output_formatter import OutputFormatterTool
from .visualization_tools import ChartGeneratorTool, TableProcessorTool
from .research_strategies import ResearchStrategy  # ADD THIS
from .langchain_tools import (
    WebSearchToolWrapper, ContentAnalyzerToolWrapper, ResearchSummarizerToolWrapper,
    CodeGeneratorToolWrapper, CodeValidatorToolWrapper, WebScraperToolWrapper,
    OutputFormatterToolWrapper, ChartGeneratorToolWrapper, TableProcessorToolWrapper,
    CodeExecutionToolWrapper
)

__all__ = [
    'WebSearchTool', 'WebScraperTool', 'ContentAnalyzerTool', 'ResearchSummarizerTool',
    'CodeGeneratorTool', 'CodeValidatorTool', 'CodeExecutionTool', 'OutputFormatterTool',
    'ChartGeneratorTool', 'TableProcessorTool', 'ResearchStrategy',  # ADD ResearchStrategy
    'WebSearchToolWrapper', 'ContentAnalyzerToolWrapper', 'ResearchSummarizerToolWrapper',
    'CodeGeneratorToolWrapper', 'CodeValidatorToolWrapper', 'WebScraperToolWrapper',
    'OutputFormatterToolWrapper', 'ChartGeneratorToolWrapper', 'TableProcessorToolWrapper',
    'CodeExecutionToolWrapper'
]