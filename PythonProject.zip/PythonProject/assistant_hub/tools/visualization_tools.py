# assistant_hub/tools/visualization_tools.py
from typing import Dict, Any, List
from assistant_hub.toolsIf.toolsIF import ITool
import re
import matplotlib.pyplot as plt
import io
import base64


class ChartGeneratorTool(ITool):
    def run(self, data, chart_type="bar", output_format="matplotlib", **kwargs):
        try:
            labels = data.get("labels", [])
            values = data.get("values", [])

            if output_format == "matplotlib":
                fig, ax = plt.subplots()
                ax.bar(labels, values, color="skyblue")
                ax.set_title("Generated Chart")
                ax.set_ylabel("Value")

                buf = io.BytesIO()
                plt.savefig(buf, format="png")
                buf.seek(0)
                img_b64 = base64.b64encode(buf.read()).decode("utf-8")
                plt.close(fig)

                return {
                    "text": "Chart generated successfully.",
                    "image_base64": img_b64,
                    "success": True
                }
            else:
                # fallback to simple text chart
                chart = "Chart\n\n" + "\n".join(f"{l}: {'█'*v}" for l, v in zip(labels, values))
                return {"text": chart, "success": True}

        except Exception as e:
            return {"text": f"Chart generation failed: {e}", "success": False}

# 🔥 Table Processor Tool
class TableProcessorTool(ITool):
    def run(self, content: str,
            table_format: str = "auto",
            extraction_method: str = "auto") -> Dict[str, Any]:
        try:
            tables = self._extract_tables(content, extraction_method)

            processed_tables = []
            for table in tables:
                if table_format == "markdown":
                    processed_tables.append(self._table_to_markdown(table))
                elif table_format == "html":
                    processed_tables.append(self._table_to_html(table))
                elif table_format == "csv":
                    processed_tables.append(self._table_to_csv(table))
                else:
                    processed_tables.append(self._table_to_markdown(table))

            return {
                "tables_found": len(tables),
                "processed_tables": processed_tables,
                "format": table_format,
                "success": True
            }

        except Exception as e:
            return {
                "error": f"Table processing failed: {str(e)}",
                "success": False
            }

    def _extract_tables(self, content: str, method: str) -> List[Any]:
        tables = []
        tables.extend(self._extract_markdown_tables(content))
        tables.extend(self._extract_html_tables(content))
        tables.extend(self._extract_pattern_tables(content))
        return tables

    def _extract_markdown_tables(self, content: str) -> List[Dict]:
        tables = []
        lines = content.split('\n')
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('|') and '---' not in line:
                headers = [cell.strip() for cell in line.split('|')[1:-1]]
                table_data = {'headers': headers, 'rows': []}
                i += 2
                while i < len(lines) and lines[i].strip().startswith('|'):
                    row = [cell.strip() for cell in lines[i].split('|')[1:-1]]
                    table_data['rows'].append(row)
                    i += 1
                if table_data['rows']:
                    tables.append(table_data)
            else:
                i += 1
        return tables

    def _extract_html_tables(self, content: str) -> List[Dict]:
        tables = []
        table_pattern = r'<table[^>]*>(.*?)</table>'
        matches = re.findall(table_pattern, content, re.DOTALL | re.IGNORECASE)
        for match in matches:
            row_pattern = r'<tr[^>]*>(.*?)</tr>'
            rows = re.findall(row_pattern, match, re.DOTALL | re.IGNORECASE)
            if rows:
                table_data = {'headers': [], 'rows': []}
                for row in rows:
                    cell_pattern = r'<t[dh][^>]*>(.*?)</t[dh]>'
                    cells = re.findall(cell_pattern, row, re.DOTALL | re.IGNORECASE)
                    clean_cells = [re.sub('<[^>]+>', '', cell).strip() for cell in cells]
                    if clean_cells:
                        table_data['rows'].append(clean_cells)
                if table_data['rows']:
                    tables.append(table_data)
        return tables

    def _extract_pattern_tables(self, content: str) -> List[Dict]:
        tables = []
        lines = content.split('\n')
        for i, line in enumerate(lines):
            if self._looks_like_table_row(line):
                context_start = max(0, i - 2)
                context_end = min(len(lines), i + 3)
                table_context = lines[context_start:context_end]
                table_data = self._parse_table_from_context(table_context)
                if table_data:
                    tables.append(table_data)
        return tables

    def _looks_like_table_row(self, line: str) -> bool:
        if len(re.findall(r'\s{2,}', line)) >= 2:
            return True
        if len(re.findall(r'\|\s*[^|]+\s*\|', line)) >= 2:
            return True
        return False

    def _parse_table_from_context(self, context_lines: List[str]) -> Dict:
        if len(context_lines) < 2:
            return None
        potential_headers = []
        rows = []
        for line in context_lines:
            clean_line = line.strip()
            if clean_line:
                cells = re.split(r'\s{2,}|\t', clean_line)
                cells = [cell.strip() for cell in cells if cell.strip()]
                if cells:
                    if not potential_headers and len(cells) > 1:
                        potential_headers = cells
                    else:
                        rows.append(cells)
        if len(rows) >= 1:
            return {'headers': potential_headers, 'rows': rows, 'type': 'pattern_detected'}
        return None

    def _table_to_markdown(self, table: Dict) -> str:
        if not table.get('rows'):
            return "No table data"
        headers = table.get('headers', [f"Column {i + 1}" for i in range(len(table['rows'][0]))])
        rows = table['rows']
        output = "| " + " | ".join(headers) + " |\n"
        output += "|" + "|".join(["---"] * len(headers)) + "|\n"
        for row in rows:
            output += "| " + " | ".join(str(cell) for cell in row) + " |\n"
        return output

    def _table_to_html(self, table: Dict) -> str:
        if not table.get('rows'):
            return "<p>No table data</p>"
        headers = table.get('headers', [f"Column {i + 1}" for i in range(len(table['rows'][0]))])
        rows = table['rows']
        html = "<table border='1'>\n"
        if headers:
            html += "  <tr>\n"
            for header in headers:
                html += f"    <th>{header}</th>\n"
            html += "  </tr>\n"
        for row in rows:
            html += "  <tr>\n"
            for cell in row:
                html += f"    <td>{cell}</td>\n"
            html += "  </tr>\n"
        html += "</table>"
        return html

    def _table_to_csv(self, table: Dict) -> str:
        if not table.get('rows'):
            return ""
        headers = table.get('headers', [f"Column {i + 1}" for i in range(len(table['rows'][0]))])
        rows = table['rows']
        csv_lines = [",".join(f'"{header}"' for header in headers)]
        for row in rows:
            csv_lines.append(",".join(f'"{cell}"' for cell in row))
        return "\n".join(csv_lines)

    def get_description(self) -> str:
        return "Extracts and processes tables from content into various formats (markdown, HTML, CSV)"

