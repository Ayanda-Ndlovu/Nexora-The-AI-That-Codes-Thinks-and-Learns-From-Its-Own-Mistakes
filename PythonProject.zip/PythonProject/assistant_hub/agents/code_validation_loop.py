# assistant_hub/agents/code_validation_loop.py
from assistant_hub.agents.coder_agent import CoderAgent
from assistant_hub.agents.validator_agent import ValidatorAgent
from assistant_hub.core.logging_config import logger
import traceback

class AutoCodingAgent:
    """
    Coordinates CoderAgent and ValidatorAgent for iterative code improvement,
    including runtime sandboxed validation.
    """

    def __init__(self, max_attempts=6, min_clarity_score=4, min_grammar_score=4):
        self.coder = CoderAgent()
        self.validator = ValidatorAgent()
        self.max_attempts = max_attempts
        self.min_clarity_score = min_clarity_score
        self.min_grammar_score = min_grammar_score

    def generate_code(self, prompt: str, language="python", test_cases=None) -> dict:
        attempt = 0
        code_text = ""
        validation_feedback = {}
        runtime_feedback = {}

        while attempt < self.max_attempts:
            attempt += 1
            logger.info(f"[AutoCodingAgent] Attempt {attempt} for prompt: {prompt}")

            # Generate code
            coder_result = self.coder.process(prompt, language)
            code_text = coder_result.get("code", "")

            # Textual validation
            validation_feedback = self.validator.process(code_text)

            clarity_score = validation_feedback.get("clarity_score", 5)
            grammar_score = validation_feedback.get("grammar_score", 5)
            is_factually_correct = validation_feedback.get("is_factually_correct", True)

            # Runtime validation
            runtime_feedback = self._run_sandboxed_tests(code_text, test_cases or [])
            runtime_passed = runtime_feedback.get("success", True)

            if clarity_score >= self.min_clarity_score and grammar_score >= self.min_grammar_score \
               and is_factually_correct and runtime_passed:
                break  # Code passes all validations

            # Prepare feedback for next iteration
            issues = validation_feedback.get("issues", []) + runtime_feedback.get("errors", [])
            recommendations = validation_feedback.get("recommendations", [])
            feedback_text = "\n".join(issues + recommendations)
            prompt = (
                f"Rewrite the following code to fix issues and improve quality:\n{code_text}\n"
                f"Feedback:\n{feedback_text}\n"
                "Requirements:\n- Fix all errors\n- Ensure clarity\n- Pass all test cases"
            )

        return {
            "final_code": code_text,
            "validation": validation_feedback,
            "runtime": runtime_feedback,
            "attempts": attempt
        }

    def _run_sandboxed_tests(self, code: str, test_cases: list) -> dict:
        feedback = {"success": True, "errors": []}

        for idx, case in enumerate(test_cases, start=1):
            try:
                local_vars = {}
                global_vars = {"__builtins__": {"range": range, "len": len, "print": print, "sorted": sorted}}

                exec(code, global_vars, local_vars)
                func_name = next((name for name in local_vars if callable(local_vars[name])), None)
                if not func_name:
                    feedback["success"] = False
                    feedback["errors"].append("No callable function found in code.")
                    continue

                func = local_vars[func_name]
                result = func(*case.get("input", ()))
                if result != case.get("expected_output"):
                    feedback["success"] = False
                    feedback["errors"].append(
                        f"Test case {idx} failed: input={case['input']}, expected={case['expected_output']}, got={result}"
                    )

            except Exception:
                feedback["success"] = False
                feedback["errors"].append(f"Test case {idx} exception:\n{traceback.format_exc()}")

        return feedback
