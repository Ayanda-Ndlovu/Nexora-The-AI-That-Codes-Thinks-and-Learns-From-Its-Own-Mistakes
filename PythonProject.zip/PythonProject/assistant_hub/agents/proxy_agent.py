# assistant_hub/agents/proxy_agent.py - COMPLETE FIXED VERSION

from typing import Any, Dict
from assistant_hub.agents.base_agent import BaseAgent
from assistant_hub.core.logging_config import logger


class ProxyAgent(BaseAgent):
    """Acts as a router/mediator between agents."""

    def __init__(self, name: str, llm_interface: Any, memory: Dict[str, Any] = None, **kwargs):
        self.coordinator = kwargs.pop("coordinator", None)
        self.agents = kwargs.pop("agents", {})
        self.conversation_history = []  # Simple conversation memory
        super().__init__(name, llm_interface, memory)

        logger.info(f"[ProxyAgent] Initialized with {len(self.agents)} agents available")

    def process(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        The ProxyAgent's process method delegates to the routing logic.
        """
        logger.info(f"[ProxyAgent] Received prompt: {prompt[:50]}...")

        # 1. Prefer agents passed in kwargs.
        agents_to_route = kwargs.get("agents")

        # 2. Fall back to agents stored in self (passed during init)
        if not agents_to_route:
            agents_to_route = self.agents
            logger.info(f"[ProxyAgent] Using self.agents: {list(agents_to_route.keys())}")

        # 3. If still empty, try to get agents from the coordinator
        if not agents_to_route and self.coordinator and hasattr(self.coordinator, 'agents'):
            agents_to_route = self.coordinator.agents
            logger.info(f"[ProxyAgent] Retrieved from coordinator: {list(agents_to_route.keys())}")

        if not agents_to_route:
            logger.error("[ProxyAgent] Cannot route: No agents available for routing.")
            return {"text": "Error: Cannot route, agent list is empty."}

        logger.info(f"[ProxyAgent] Routing with agents: {list(agents_to_route.keys())}")
        return self.route(prompt, agents_to_route)

    # ✅ ADD THE MISSING ROUTE METHOD
    def route(self, user_query: str, agents: dict):
        logger.info(f"[ProxyAgent] Routing query: '{user_query}'")
        logger.info(f"[ProxyAgent] Available agents: {list(agents.keys())}")

        user_query_lower = user_query.lower()
        logger.info(f"[ProxyAgent] Query lower: '{user_query_lower}'")

        # Enhanced routing keywords
        ROUTING_KEYWORDS = {
            "coder": ["code", "script", "python", "javascript", "java", "c++", "debug", "error",
                      "write a", "implement", "function", "program", "algorithm", "develop",
                      "sort", "calculate", "compute", "algorithm"],
            "planner": ["plan", "steps", "break down", "goal", "schedule", "task list",
                        "how to", "process", "workflow", "strategy", "approach"],
            "researcher": ["research", "find", "latest news", "analyze", "summarize",
                           "web search", "what is", "who is", "tell me about", "information",
                           "history", "facts", "explain", "about", "general"],
            "validator": ["check", "validate", "correctness", "accuracy", "fact check",
                          "review", "is this true", "verify", "proof"],
        }

        # Enhanced keyword matching with scoring
        best_agent = None
        best_score = 0

        for agent_name, keywords in ROUTING_KEYWORDS.items():
            if agent_name not in agents:
                logger.warning(f"[ProxyAgent] Agent '{agent_name}' not in available agents")
                continue

            score = 0
            matched_keywords = []

            for keyword in keywords:
                if keyword in user_query_lower:
                    score += 1
                    matched_keywords.append(keyword)

            if score > best_score:
                best_score = score
                best_agent = agent_name
                logger.info(f"[ProxyAgent] Candidate: {agent_name} with score {score} (keywords: {matched_keywords})")

        if best_agent and best_score >= 1:
            logger.info(f"[ProxyAgent] 🎯 Routed to {best_agent.capitalize()}Agent with score {best_score}")
            try:
                response = agents[best_agent].process(user_query)
                logger.info(f"[ProxyAgent] {best_agent.capitalize()}Agent response successful")

                # Store conversation history
                self.conversation_history.append(f"User: {user_query}")
                self.conversation_history.append(f"Assistant: {response.get('text', '')[:100]}...")
                if len(self.conversation_history) > 6:  # Keep last 3 exchanges
                    self.conversation_history = self.conversation_history[-6:]

                return response
            except Exception as e:
                logger.error(f"[ProxyAgent] {best_agent.capitalize()}Agent failed: {e}")
                # Fall back to general response
                return self._get_general_response(user_query)
        else:
            logger.warning(
                f"[ProxyAgent] No specialized agent matched (best score: {best_score}). Using general response.")
            return self._get_general_response(user_query)

    def _get_general_response(self, user_query: str) -> Dict[str, Any]:
        """Get a general response with conversation context"""
        # Build context from recent history
        context = "\n".join(
            self.conversation_history[-4:]) if self.conversation_history else "No previous conversation."

        enhanced_prompt = f"""You are a helpful AI assistant. Continue the conversation naturally.

Recent conversation:
{context}

Current query: {user_query}

Assistant:"""

        logger.info("[ProxyAgent] Using contextual general response")
        response = super().process(enhanced_prompt)

        # Store assistant response in history
        if "text" in response:
            self.conversation_history.append(f"User: {user_query}")
            self.conversation_history.append(f"Assistant: {response['text'][:100]}...")
            if len(self.conversation_history) > 6:
                self.conversation_history = self.conversation_history[-6:]

        return response