# assistant_hub/agents/coder_agent.py

from assistant_hub.agents.base_agent import BaseAgent
from assistant_hub.core.logging_config import logger
import re
import time

class CoderAgent(BaseAgent):
    """Generates, validates, and optionally executes code."""

    def process(self, prompt: str, language: str = "python", max_attempts: int = 3, **kwargs):
        logger.info(f"[CoderAgent] Processing code request: {prompt[:50]}...")
        attempt = 0
        final_code = None
        validation_result = None
        execution_result = None

        while attempt < max_attempts:
            attempt += 1
            logger.info(f"[CoderAgent] Attempt {attempt} generating code...")

            # Generate code
            code_prompt = self._build_code_prompt(prompt, language)
            response = super().process(code_prompt)
            raw_text = response.get("text", "")
            code_text = self._extract_code_from_response(raw_text, language)

            # Fallback if generation fails
            if not code_text or len(code_text.strip()) < 10:
                code_text = self._get_fallback_code(prompt, language)

            # Validate code
            validator = kwargs.get("validator")
            if validator:
                validation_result = validator.process(code_text)
                score = validation_result.get("score", 0)
                if score >= 0.9:
                    logger.info(f"[CoderAgent] Validation passed with score {score}")
                    final_code = code_text
                    break
                else:
                    logger.info(f"[CoderAgent] Validation failed (score {score}), retrying...")
                    continue
            else:
                # No validator provided, accept first generation
                final_code = code_text
                break

        # Optional: execute code in sandbox
        if language == "python":
            execution_result = self._execute_code(final_code, language)

        # Return structured response
        result_text = f"```{language}\n{final_code}\n```"
        if execution_result:
            if execution_result.get("success"):
                result_text += f"\n\n**Execution Output:**\n{execution_result.get('output', 'No output')}"
            else:
                result_text += f"\n\n**Execution Error:**\n{execution_result.get('error', 'Unknown error')}"

        return {
            "text": result_text,
            "code": final_code,
            "language": language,
            "validation": validation_result,
            "execution": execution_result,
            "attempts": attempt
        }

    # ------------------------------
    # Helper methods
    # ------------------------------
    def _build_code_prompt(self, prompt: str, language: str) -> str:
        """Build prompt for code generation."""
        return f"""Generate clean, working {language} code for this request.
Requirements:
- Include proper error handling
- Add comments for clarity
- Return ONLY the code without explanations

Request: {prompt}

Code:"""

    def _get_fallback_code(self, prompt: str, language: str) -> str:
        return f"""# Fallback code for: {prompt}
def main():
    print("Implementation placeholder for: {prompt}")

if __name__ == "__main__":
    main()"""

    def _extract_code_from_response(self, text: str, language: str) -> str:
        patterns = [
            rf"```{language}\n(.*?)\n```",
            r"```\n(.*?)\n```",
            rf"```{language}(.*?)```",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                return match.group(1).strip()
        return text.strip()

    def _execute_code(self, code: str, language: str) -> dict:
        if language != "python":
            return {"success": False, "error": "Only Python execution supported"}
        try:
            import io
            import sys
            old_stdout = sys.stdout
            sys.stdout = mystdout = io.StringIO()
            exec(code, {})
            output = mystdout.getvalue()
            sys.stdout = old_stdout
            return {"success": True, "output": output}
        except Exception as e:
            return {"success": False, "error": str(e)}
