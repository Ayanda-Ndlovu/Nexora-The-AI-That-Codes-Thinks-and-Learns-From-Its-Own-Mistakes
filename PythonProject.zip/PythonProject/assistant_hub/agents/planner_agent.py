# assistant_hub/agents/planner_agent.py
from assistant_hub.agents.base_agent import BaseAgent
import json


class PlannerAgent(BaseAgent):
    """
    Analyzes a user goal and generates a structured plan (e.g., use ResearchAgent or CodeAgent).
    The plan is a JSON object for execution by the AgentCoordinator.
    """

    def process(self, goal: str) -> dict:
        """
        Generates a structured plan for the AgentCoordinator.

        Plan Format:
        {
          "action": "research" | "code" | "default",
          "query": "The simplified query/code for the specific agent"
        }
        """
        # A robust planner would use the LLM to choose the action.
        # This prompt forces the LLM to output structured JSON for reliable parsing.
        prompt = (
            "Analyze the user's goal and generate a JSON plan to address it. "
            "Choose one 'action' from: 'research' (for information retrieval), 'code' (for computation or coding tasks), or 'default' (for simple chat).\n"
            "Goal: '{goal}'\n"
            "Output the plan as a single, valid JSON object with keys 'action' and 'query'.\n"
            "Example 1 (Research): {{\"action\": \"research\", \"query\": \"Latest discoveries in quantum computing\"}}\n"
            "Example 2 (Code): {{\"action\": \"code\", \"query\": \"Plot y = x^2 for x=1 to 10\"}}\n"
            "JSON Plan:"
        ).format(goal=goal)

        # Call the LLM with a low temperature to encourage structured output
        response = super().process(prompt, temperature=0.1)
        plan_text = response.get("text", "")

        try:
            # Attempt to parse the structured JSON plan
            # Note: The LLM may sometimes wrap the JSON in markdown code fences, which we must strip.
            if plan_text.startswith("```json") and plan_text.endswith("```"):
                plan_text = plan_text[len("```json"):-len("```")].strip()
            elif plan_text.startswith("```") and plan_text.endswith("```"):
                plan_text = plan_text[len("```"):-len("```")].strip()

            plan = json.loads(plan_text)

            # Simple validation for a minimal viable plan
            if plan.get("action") in ["research", "code", "default"] and "query" in plan:
                return {"plan": plan}
            else:
                raise ValueError("Invalid plan structure or action type.")

        except (json.JSONDecodeError, ValueError) as e:
            return {
                "plan": {"action": "default", "query": goal},
                "error": f"Planner failed to produce valid JSON. Error: {e}"
            }