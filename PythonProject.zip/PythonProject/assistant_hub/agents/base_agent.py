# assistant_hub/agents/base_agent.py - FIXED VERSION

import time
from typing import Any, Dict
from assistant_hub.core.logging_config import logger
from assistant_hub.training.collector import collect_training_data


class BaseAgent:
    def __init__(self, name: str, llm_interface, memory=None):
        self.name = name
        self.llm = llm_interface
        self.memory = memory or {}

    def process(self, prompt: str, **kwargs) -> Dict[str, Any]:
        start = time.time()
        logger.info(f"[{self.name}] Processing request")

        # FIX: Explicitly pass the prompt using the 'prompts' keyword argument
        response = self.llm.generate(prompts=[[prompt]], **kwargs)
        duration = time.time() - start

        logger.info(f"[{self.name}] Completed in {duration:.2f}s")

        # ✅ FIX: Use the correct function signature
        # The decorator version expects different parameters, so use the direct function
        from assistant_hub.training.collector import log_training_interaction
        log_training_interaction(
            agent=self.name,
            input_text=prompt,
            output_text=response.get("text", ""),
            metadata={"duration": duration},
        )

        return response