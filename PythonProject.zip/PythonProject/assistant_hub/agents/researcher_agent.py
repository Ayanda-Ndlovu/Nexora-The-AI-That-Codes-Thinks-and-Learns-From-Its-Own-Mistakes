# assistant_hub/agents/researcher_agent.py - FIXED VERSION
from assistant_hub.agents.base_agent import BaseAgent
from assistant_hub.core.logging_config import logger


class ResearcherAgent(BaseAgent):
    """Agent specialized in research tasks using web search and content analysis."""

    def process(self, query: str, **kwargs) -> dict:
        logger.info(f"[ResearcherAgent] Processing research request: {query}")

        try:
            # Enhanced research prompt
            research_prompt = self._build_research_prompt(query)

            response = super().process(research_prompt)
            raw_text = response.get("text", "")

            # If we have access to research tools, use them
            research_result = self._conduct_research(query)

            return {
                "text": raw_text,
                "research": research_result,
                "query": query,
                "success": True
            }

        except Exception as e:
            logger.error(f"[ResearcherAgent] Error during research: {e}")
            return {
                "text": f"I encountered an error while researching: {str(e)}",
                "query": query,
                "success": False,
                "error": str(e)
            }

    def _build_research_prompt(self, query: str) -> str:
        """Build optimized prompt for research tasks"""
        return f"""Please research the following topic and provide a comprehensive summary:

Topic: {query}

Provide:
1. Key findings and facts
2. Important dates or statistics if relevant  
3. Current trends or developments
4. Reliable sources or references

Research Summary:"""

    def _conduct_research(self, query: str):
        """Conduct research using available tools - with lazy imports to avoid circular deps"""
        try:
            # LAZY IMPORT to avoid circular dependencies
            from assistant_hub.core.dependency_injector import container

            research_strategy = container.resolve('ResearchStrategy')
            if research_strategy:
                return research_strategy.execute(query)
            else:
                return {"error": "Research tools not available"}

        except Exception as e:
            logger.warning(f"Research tools not available: {e}")
            return {"error": f"Research tools unavailable: {str(e)}"}