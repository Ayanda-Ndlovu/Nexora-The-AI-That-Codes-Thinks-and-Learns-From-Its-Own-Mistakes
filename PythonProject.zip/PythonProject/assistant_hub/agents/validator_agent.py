# assistant_hub/agents/validator_agent.py

from assistant_hub.agents.base_agent import BaseAgent
from assistant_hub.core.logging_config import logger

class ValidatorAgent(BaseAgent):
    """Validates code for correctness and provides a score."""

    def process(self, code_text: str) -> dict:
        logger.info("[ValidatorAgent] Validating code...")
        # Use simple heuristics: can it compile?
        try:
            compile(code_text, '<string>', 'exec')
            valid = True
            message = "Code syntax valid"
            score = 1.0  # perfect score
        except SyntaxError as e:
            valid = False
            message = f"Syntax error: {e}"
            score = 0.0
        except Exception as e:
            valid = False
            message = f"Execution error: {e}"
            score = 0.5

        logger.info(f"[ValidatorAgent] Validation result: {message}, score: {score}")
        return {"valid": valid, "message": message, "score": score}
