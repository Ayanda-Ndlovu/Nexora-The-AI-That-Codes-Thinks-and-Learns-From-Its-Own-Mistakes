# assistant_hub/training/fine_tuning_manager.py - UPDATED VERSION

import json
import os
import subprocess
import tempfile
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass
import pandas as pd
import yaml

from ..core.config import FineTuningConfig, FineTuningMethod
from assistant_hub.core.logging_config import logger


@dataclass
class TrainingExample:
    prompt: str
    completion: str
    metadata: Optional[Dict[str, Any]] = None


class OllamaFineTuningManager:
    """Actual Ollama fine-tuning implementation"""

    def __init__(self, config: FineTuningConfig):
        self.config = config
        self.training_data: List[TrainingExample] = []
        os.makedirs(config.dataset_path, exist_ok=True)
        os.makedirs(config.output_dir, exist_ok=True)

    def collect_interaction(self, prompt: str, response: str, agent_type: str, success: bool = True):
        """Collect interaction data for fine-tuning with quality filtering"""

        # Enhanced quality filtering
        if not self._is_high_quality_interaction(prompt, response):
            logger.debug(f"Skipping low-quality interaction for {agent_type}")
            return

        example = TrainingExample(
            prompt=prompt,
            completion=response,
            metadata={
                'agent_type': agent_type,
                'timestamp': datetime.now().isoformat(),
                'success': success,
                'conversation_id': self._get_current_conversation_id(),
                'turn_index': self._get_turn_index(agent_type),
                'quality_score': self._calculate_quality_score(prompt, response)
            }
        )
        self.training_data.append(example)

        # Auto-save periodically
        if len(self.training_data) % 10 == 0:
            self.save_training_data()

        # Auto fine-tune if enough high-quality data collected
        if len(self.training_data) >= self.config.batch_size * 2:
            logger.agent_activity("FineTuningManager", "Auto fine-tune triggered")
            self.fine_tune_model("gemma:2b")

    def _is_high_quality_interaction(self, prompt: str, response: str) -> bool:
        """Determine if interaction is high quality for training"""
        if not prompt or not response:
            return False

        prompt_words = len(prompt.split())
        response_words = len(response.split())

        # Quality criteria
        if prompt_words < 3 or response_words < 5:
            return False
        if response.lower().startswith(('error', 'sorry', 'i cannot')):
            return False
        if any(phrase in response.lower() for phrase in ['i don\'t know', 'not sure', 'unable to']):
            return False

        return True

    def _calculate_quality_score(self, prompt: str, response: str) -> float:
        """Calculate quality score for training example"""
        score = 0.0

        # Length-based scoring
        prompt_len = len(prompt.split())
        response_len = len(response.split())

        if 5 <= prompt_len <= 100:
            score += 0.3
        if 10 <= response_len <= 500:
            score += 0.3

        # Content-based scoring
        if '?' in prompt:  # Question prompts are good
            score += 0.2
        if any(marker in response for marker in ['```', '###', '**']):  # Structured response
            score += 0.2

        return min(score, 1.0)

    def prepare_ollama_dataset(self, base_model: str) -> str:
        """Prepare dataset in Ollama Modelfile format"""
        if not self.training_data:
            raise ValueError("No training data collected")

        # Filter high-quality examples
        high_quality_data = [
            ex for ex in self.training_data
            if ex.metadata.get('quality_score', 0) >= 0.5
        ]

        if not high_quality_data:
            raise ValueError("No high-quality training data available")

        # Create Modelfile content
        modelfile_content = f"FROM {base_model}\n\n"
        modelfile_content += "PARAMETER temperature 0.7\n"
        modelfile_content += "PARAMETER num_ctx 4096\n\n"
        modelfile_content += "SYSTEM \"\"\"You are a helpful AI assistant specialized in research and coding tasks.\"\"\"\n\n"

        # Add training examples as message templates
        for i, example in enumerate(high_quality_data[:100]):  # Limit to 100 examples
            modelfile_content += f"# Example {i + 1}\n"
            modelfile_content += f"MESSAGE user {json.dumps(example.prompt)}\n"
            modelfile_content += f"MESSAGE assistant {json.dumps(example.completion)}\n\n"

        # Save Modelfile
        modelfile_path = os.path.join(self.config.dataset_path, "Modelfile")
        with open(modelfile_path, 'w', encoding='utf-8') as f:
            f.write(modelfile_content)

        return modelfile_path

    def fine_tune_model(self, base_model: str) -> str:
        """Execute actual Ollama fine-tuning process"""
        try:
            logger.info(f"🔧 Starting Ollama fine-tuning for {base_model}...")

            # Prepare dataset
            modelfile_path = self.prepare_ollama_dataset(base_model)

            # Generate model name
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            model_name = f"{base_model}-fine-tuned-{timestamp}"

            # Execute Ollama create command
            result = self._run_ollama_create(modelfile_path, model_name)

            if result:
                logger.info(f"✅ Fine-tuning completed successfully! Model: {model_name}")

                # Save model info
                model_info = {
                    "model_name": model_name,
                    "base_model": base_model,
                    "training_examples": len(self.training_data),
                    "training_date": datetime.now().isoformat(),
                    "hyperparameters": {
                        "learning_rate": self.config.learning_rate,
                        "num_epochs": self.config.num_epochs,
                        "batch_size": self.config.batch_size
                    }
                }

                info_path = os.path.join(self.config.output_dir, f"{model_name}_info.json")
                with open(info_path, 'w') as f:
                    json.dump(model_info, f, indent=2)

                # Clear training data after successful fine-tuning
                self.training_data.clear()

                return model_name
            else:
                logger.error("❌ Fine-tuning failed")
                return ""

        except Exception as e:
            logger.error(f"❌ Fine-tuning error: {e}")
            return ""

    def _run_ollama_create(self, modelfile_path: str, model_name: str) -> bool:
        """Execute ollama create command with the Modelfile"""
        try:
            # Build the command
            cmd = ['ollama', 'create', model_name, '-f', modelfile_path]

            logger.info(f"Running: {' '.join(cmd)}")

            # Execute with timeout
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=3600,  # 1 hour timeout
                cwd=os.path.dirname(modelfile_path)
            )

            if result.returncode == 0:
                logger.info("Ollama create completed successfully")
                logger.debug(f"Output: {result.stdout}")
                return True
            else:
                logger.error(f"Ollama create failed: {result.stderr}")
                return False

        except subprocess.TimeoutExpired:
            logger.error("Fine-tuning timed out after 1 hour")
            return False
        except Exception as e:
            logger.error(f"Error running ollama create: {e}")
            return False

    def create_lora_config(self, base_model: str) -> str:
        """Create LoRA configuration for advanced fine-tuning"""
        lora_config = {
            "model_name": f"{base_model}-lora",
            "base_model": base_model,
            "lora_rank": 16,
            "lora_alpha": 32,
            "lora_dropout": 0.1,
            "target_modules": ["q_proj", "v_proj", "k_proj", "o_proj"],
            "training_parameters": {
                "learning_rate": self.config.learning_rate,
                "num_epochs": self.config.num_epochs,
                "batch_size": self.config.batch_size,
                "warmup_steps": 100,
                "weight_decay": 0.01
            }
        }

        config_path = os.path.join(self.config.output_dir, "lora_config.json")
        with open(config_path, 'w') as f:
            json.dump(lora_config, f, indent=2)

        return config_path

    def evaluate_fine_tuned_model(self, model_name: str, test_prompts: List[str]) -> Dict[str, float]:
        """Evaluate fine-tuned model against test prompts"""
        logger.info(f"🧪 Evaluating model: {model_name}")

        try:
            # Simple evaluation using Ollama API
            import requests
            from ..core.config import Config

            config = Config()
            base_url = config.OLLAMA_BASE_URL

            scores = {
                "response_quality": 0.0,
                "relevance": 0.0,
                "completeness": 0.0,
                "total_tested": len(test_prompts)
            }

            successful_tests = 0

            for prompt in test_prompts:
                try:
                    response = self._query_model_api(base_url, model_name, prompt)
                    if response and "error" not in response:
                        # Simple scoring based on response characteristics
                        score = self._score_response(prompt, response)
                        scores["response_quality"] += score
                        scores["relevance"] += 0.8 if any(
                            word in response.lower() for word in prompt.lower().split()[:3]) else 0.2
                        scores["completeness"] += 0.7 if len(response.split()) > 10 else 0.3
                        successful_tests += 1

                except Exception as e:
                    logger.warning(f"Test failed for prompt: {prompt[:50]}... - {e}")

            # Calculate averages
            if successful_tests > 0:
                for key in ["response_quality", "relevance", "completeness"]:
                    scores[key] = round(scores[key] / successful_tests, 3)

            scores["success_rate"] = round(successful_tests / len(test_prompts), 3)

            # Save evaluation results
            eval_path = os.path.join(self.config.output_dir, f"{model_name}_evaluation.json")
            with open(eval_path, 'w') as f:
                json.dump(scores, f, indent=2)

            return scores

        except Exception as e:
            logger.error(f"Evaluation failed: {e}")
            return {"error": str(e)}

    def _query_model_api(self, base_url: str, model_name: str, prompt: str) -> str:
        """Query Ollama API for model response"""
        try:
            response = requests.post(
                f"{base_url}/api/generate",
                json={
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                },
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            return data.get("response", "")
        except Exception as e:
            logger.error(f"API query failed: {e}")
            return ""

    def _score_response(self, prompt: str, response: str) -> float:
        """Score response quality (0.0 to 1.0)"""
        score = 0.0

        # Length-based scoring
        response_len = len(response.split())
        if 15 <= response_len <= 500:
            score += 0.4

        # Content-based scoring
        if any(marker in response for marker in ['```', '###', '**', '- ']):  # Structured content
            score += 0.3
        if not response.lower().startswith(('i', 'you', 'we', 'the')):  # Not starting with common weak phrases
            score += 0.3

        return min(score, 1.0)

    def save_training_data(self, filename: Optional[str] = None):
        """Save training data to JSONL format"""
        if not self.training_data:
            return

        if not filename:
            filename = f"training_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"

        filepath = os.path.join(self.config.dataset_path, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            for example in self.training_data:
                record = {
                    "prompt": example.prompt,
                    "completion": example.completion,
                    "metadata": example.metadata
                }
                f.write(json.dumps(record) + '\n')

        logger.info(f"💾 Saved {len(self.training_data)} training examples to {filepath}")

    def _get_current_conversation_id(self) -> str:
        """Generate conversation ID for grouping multi-turn interactions"""
        return datetime.now().strftime("%Y%m%d")

    def _get_turn_index(self, agent_type: str) -> int:
        """Count turns per agent type for conversation tracking"""
        agent_examples = [ex for ex in self.training_data if ex.metadata.get("agent_type") == agent_type]
        return len(agent_examples) + 1


# Update the main FineTuningManager to use the actual implementation
class FineTuningManager(OllamaFineTuningManager):
    """Main fine-tuning manager with actual Ollama integration"""

    def __init__(self, config: FineTuningConfig):
        super().__init__(config)
        logger.info("✅ Fine-tuning manager initialized with actual Ollama integration")