# assistant_hub/training/collector.py
from functools import wraps
import logging

import json
import os
from datetime import datetime



logger = logging.getLogger(__name__)


def collect_training_data(agent_name_func):
    """
    Decorator to collect interaction data for fine-tuning.
    It wraps a method that generates an LLM response.
    """
    from assistant_hub.core.dependency_injector import container
    def decorator(func):
        @wraps(func)
        def wrapper(self, prompt, *args, **kwargs):
            # Execute the original LLM generation method
            response = func(self, prompt, *args, **kwargs)

            # Determine success and extract response text
            success = "error" not in str(response).lower()
            response_text = self._extract_response_text(response) if hasattr(self, '_extract_response_text') else str(
                response)

            try:
                # Resolve the manager from the container
                fine_tuning_manager = container.resolve('FineTuningManager')

                # Get the agent name using the provided function
                agent_name = agent_name_func(self)

                fine_tuning_manager.collect_interaction(
                    prompt=prompt,
                    response=response_text,
                    agent_type=agent_name,
                    success=success
                )
            except Exception as e:
                logger.warning(f"Failed to collect training data: {e}")

            return response

        return wrapper

    return decorator

# ✅ Optional runtime-safe collector for manual logging (non-decorator use)
def log_training_interaction(agent: str, input_text: str, output_text: str, metadata: dict = None):
    """
    Simple training data logger for use outside decorators (like in run_assistant.py).
    """
    try:
        record = {
            "timestamp": datetime.utcnow().isoformat(),
            "agent": agent,
            "input": input_text,
            "output": output_text,
            "metadata": metadata or {},
        }

        os.makedirs("/tmp/assistant_logs", exist_ok=True)
        log_file = "/tmp/assistant_logs/training_data.jsonl"

        with open(log_file, "a") as f:
            f.write(json.dumps(record) + "\n")

        logger.info(f"✅ Logged training interaction for agent '{agent}'")

    except Exception as e:
        logger.warning(f"Failed to log training data: {e}")
