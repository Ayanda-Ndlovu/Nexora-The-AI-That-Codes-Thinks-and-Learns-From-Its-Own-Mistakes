# assistant_hub/streamlit_app.py
import streamlit as st
import os
import sys
import json
import base64
from typing import Optional, Dict

# Ensure package root on path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from assistant_hub.ui.helpers import (
    new_chat, get_chat, append_message, save_current_chat_to_log,
    load_memory, save_memory
)
from assistant_hub.ui.views import chat_window, render_save_dialog, render_delete_dialog, top_bar
from assistant_hub.run_assistant import initialize_system

# ---------- App Config ----------
APP_TITLE = "Proxi"
st.set_page_config(page_title=APP_TITLE, page_icon="🤖", layout="wide")

MEMORY_DIR = os.path.join(os.path.dirname(__file__), "memory")
UPLOADS_DIR = os.path.join(MEMORY_DIR, "uploads")
os.makedirs(MEMORY_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)

# ---------- Backend Initialization ----------
if "backend_initialized" not in st.session_state:
    st.session_state.backend_initialized = False
if "backend_error" not in st.session_state:
    st.session_state.backend_error = None

if not st.session_state.backend_initialized:
    try:
        with st.spinner("⚙️ Initializing backend..."):
            coordinator, agents, proxy_agent = initialize_system()
            st.session_state.coordinator = coordinator
            st.session_state.agents = agents
            st.session_state.proxy_agent = proxy_agent
            st.session_state.backend_initialized = True
            st.session_state.backend_error = None
    except Exception as e:
        st.session_state.backend_error = str(e)
        st.session_state.backend_initialized = False
        st.error(f"❌ Backend initialization failed: {e}")

# ---------- Load Chats ----------
if "chats" not in st.session_state:
    st.session_state.chats = load_memory() or []

# Load last active chat if available
last_chat_file = os.path.join(MEMORY_DIR, "last_active_chat.txt")
if os.path.exists(last_chat_file):
    try:
        with open(last_chat_file, "r") as f:
            last_chat_id = int(f.read().strip())
        # Verify the ID exists
        if any(chat["id"] == last_chat_id for chat in st.session_state.chats):
            st.session_state.current_chat_id = last_chat_id
        else:
            st.session_state.current_chat_id = st.session_state.chats[0]["id"] if st.session_state.chats else None
    except Exception:
        st.session_state.current_chat_id = st.session_state.chats[0]["id"] if st.session_state.chats else None
else:
    st.session_state.current_chat_id = st.session_state.chats[0]["id"] if st.session_state.chats else None

# pending_action state:
# None or {"type": "new" | "switch", "target_chat_id": Optional[int], "target_title": Optional[str]}
if "pending_action" not in st.session_state:
    st.session_state.pending_action = None

# pending_delete state:
# None or {"target_chat_id": int}
if "pending_delete" not in st.session_state:
    st.session_state.pending_delete = None

# ---------- Helper: check whether a chat is saved on disk ----------
def is_chat_saved(chat_id: Optional[int]) -> bool:
    """Return True if a file for this chat id exists in MEMORY_DIR."""
    if not chat_id:
        return False
    try:
        for fn in os.listdir(MEMORY_DIR):
            if fn.lower().endswith(f"_{chat_id}.json"):
                return True
    except Exception:
        return False
    return False

# ---------- Top Bar ----------
top_bar()

# ---------- Sidebar Navigation ----------


with st.sidebar:
    st.markdown("## 💬 Conversations")

    # New Chat Button
    new_chat_clicked = st.button("➕ New Chat", key="sidebar_new_chat")

    # Build display labels and a mapping so we can show a "(current)" highlight
    display_labels = []
    display_to_id = {}
    for c in st.session_state.chats:
        title = c.get("title", f"Chat {c['id']}")
        if c.get("id") == st.session_state.current_chat_id:
            label = f"{title} (current)"
        else:
            label = title
        display_labels.append(label)
        display_to_id[label] = c.get("id")

    # Switch Conversation Dropdown (map labels -> ids)
    selected_display = st.selectbox(
        "Switch Conversation",
        options=["-- Select --"] + display_labels,
        index=(display_labels.index(next((lbl for lbl in display_labels if lbl.endswith("(current)")), None))
               + 1) if any(lbl.endswith("(current)") for lbl in display_labels) else 0,
        key="sidebar_chat_switch"
    )

# place Go and Delete side-by-side
    col_go, col_del = st.columns([1, 1])
    with col_go:
        go_clicked = st.button("Go", key="sidebar_go_button")
    with col_del:
        delete_clicked = st.button("Delete", key="sidebar_delete_button")



# ---------- Handle New Chat Click ----------
if new_chat_clicked:
    current_chat_id = st.session_state.get("current_chat_id")
    # If there is no active chat, create immediately
    if current_chat_id is None:
        new_id = new_chat()
        with open(last_chat_file, "w") as f:
            f.write(str(new_id))
        st.rerun()

    else:
        # If current chat is already saved on disk, auto-save continuation and create new
        if is_chat_saved(current_chat_id):
            save_memory(current_chat_id)  # save continuation to existing file
            new_id = new_chat()
            with open(last_chat_file, "w") as f:
                f.write(str(new_id))
            st.rerun()
        else:
            # current chat not saved yet -> prompt rename/save via pending_action
            st.session_state.pending_action = {"type": "new", "target_chat_id": None, "target_title": None}
            st.rerun()

# ---------- Handle GO button / selected_display ----------
if go_clicked:
    if not selected_display or selected_display == "-- Select --":
        st.warning("Please select a conversation from the dropdown first.")
    else:
        # Try to find target id from the in-memory mapping first
        target_id = display_to_id.get(selected_display)

        # If not found in memory, try to find a matching file in MEMORY_DIR
        if not target_id:
            search_name = selected_display.replace(" (current)", "").strip().lower()
            found = False
            for fn in os.listdir(MEMORY_DIR):
                if not fn.lower().endswith(".json"):
                    continue
                if search_name in fn.lower():
                    full = os.path.join(MEMORY_DIR, fn)
                    try:
                        with open(full, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        # if this chat id isn't already loaded, add it
                        if not any(c.get("id") == data.get("id") for c in st.session_state.chats):
                            st.session_state.chats.insert(0, data)
                        target_id = data.get("id")
                        found = True
                        break
                    except Exception as e:
                        print(f"[sidebar-go] failed to load {full}: {e}")
                        continue
            if not found and not target_id:
                st.warning("No saved conversation file found that matches the selected name.")

        # If we have a target id resolve the switching flow
        if target_id:
            # If it's already the current chat, do nothing
            if st.session_state.current_chat_id == target_id:
                st.info("Already viewing that conversation.")
            else:
                current_chat_id = st.session_state.get("current_chat_id")
                # If there's no active chat, switch immediately
                if current_chat_id is None:
                    st.session_state.current_chat_id = target_id
                    with open(last_chat_file, "w") as f:
                        f.write(str(st.session_state.current_chat_id))
                    st.success(f"Switched to chat: {selected_display}")
                    st.rerun()
                else:
                    # If current chat is already saved, auto-save continuation and switch immediately
                    if is_chat_saved(current_chat_id):
                        save_memory(current_chat_id)
                        st.session_state.current_chat_id = target_id
                        with open(last_chat_file, "w") as f:
                            f.write(str(st.session_state.current_chat_id))
                        st.success(f"Switched to chat: {selected_display}")
                        st.rerun()
                    else:
                        # current chat not saved -> prompt rename/save via pending_action
                        st.session_state.pending_action = {
                            "type": "switch",
                            "target_chat_id": target_id,
                            "target_title": selected_display
                        }
                        st.rerun()

# ---------- Handle Delete Click (delete the CURRENTLY ACTIVE conversation) ----------
if delete_clicked:
    current_chat_id = st.session_state.get("current_chat_id")
    if current_chat_id is None:
        st.warning("No active conversation to delete.")
    else:
        # Set pending_delete and show dialog in main area
        st.session_state.pending_delete = {"target_chat_id": current_chat_id}
        st.rerun()

# ---------- If pending_action is set, use the reusable dialog from views.py ----------
if st.session_state.pending_action:
    action = st.session_state.pending_action
    current_chat_id = st.session_state.get("current_chat_id")
    chat = get_chat(current_chat_id)
    default_title = chat.get("title", "Untitled Chat") if chat else "Untitled Chat"

    # Use the views render_save_dialog to show UI and get results
    result = render_save_dialog(chat=chat, default_name=default_title)

    if result.get("cancelled"):
        st.session_state.pending_action = None
        st.info("Canceled save and action.")
        st.rerun()

    if result.get("saved"):
        new_name = result.get("new_name")
        # rename current chat and save
        if chat:
            chat["title"] = new_name
            save_memory(current_chat_id)

        # perform pending action
        if action["type"] == "new":
            new_id = new_chat()
            with open(last_chat_file, "w") as f:
                f.write(str(new_id))
            st.session_state.pending_action = None
            st.success(f"Chat saved as '{new_name}'. Created new chat.")
            st.rerun()
        elif action["type"] == "switch":
            st.session_state.current_chat_id = action["target_chat_id"]
            with open(last_chat_file, "w") as f:
                f.write(str(st.session_state.current_chat_id))
            st.session_state.pending_action = None
            st.success(f"Chat saved as '{new_name}'. Switched to '{action['target_title']}'.")
            st.rerun()

    # stop further UI until user acts
    st.stop()

# ---------- If pending_delete is set, render delete dialog and handle it ----------
if st.session_state.pending_delete:
    tgt = st.session_state.pending_delete.get("target_chat_id")
    chat_to_delete = get_chat(tgt)
    result = render_delete_dialog(chat_to_delete)

    if result.get("cancelled"):
        st.session_state.pending_delete = None
        st.info("Deletion canceled.")
        st.rerun()

    if result.get("confirmed"):
        # remove from session chats
        st.session_state.chats = [c for c in st.session_state.chats if c.get("id") != tgt]
        # delete files matching _{tgt}.json
        removed_any = False
        for fn in os.listdir(MEMORY_DIR):
            if fn.lower().endswith(f"_{tgt}.json"):
                try:
                    os.remove(os.path.join(MEMORY_DIR, fn))
                    removed_any = True
                except Exception as e:
                    print(f"[delete] failed to remove {fn}: {e}")
        # clear pending delete
        st.session_state.pending_delete = None

        # If deleted chat was active, set a new current chat
        if st.session_state.get("current_chat_id") == tgt:
            st.session_state.current_chat_id = st.session_state.chats[0]["id"] if st.session_state.chats else None
            # update last_active_chat file
            if st.session_state.current_chat_id is not None:
                with open(last_chat_file, "w") as f:
                    f.write(str(st.session_state.current_chat_id))
            else:
                # remove last_active_chat.txt if no chats left
                try:
                    if os.path.exists(last_chat_file):
                        os.remove(last_chat_file)
                except Exception:
                    pass

        st.success("Conversation deleted.")
        st.rerun()

    # wait for user action
    st.stop()

# ---------- Chat Window ----------
current_chat = get_chat(st.session_state.current_chat_id)
chat_window(current_chat)

# ---------- Attachment area (images, files, audio) ----------
col_img, col_file, col_audio = st.columns(3)

with col_img:
    img = st.file_uploader("Upload image", type=["png", "jpg", "jpeg", "gif"], key="upload_image")
    if img is not None:
        # save to uploads dir
        fn = img.name
        target = os.path.join(UPLOADS_DIR, fn)
        with open(target, "wb") as f:
            f.write(img.getbuffer())
        st.success(f"Saved image: {fn}")
        if st.button("Insert image into message", key=f"insert_img_{fn}"):
            # Insert markdown reference to image into chat input (prefilled)
            insert = f"![{fn}](uploads/{fn})"
            st.session_state["user_input_box"] = (st.session_state.get("user_input_box", "") or "") + " " + insert
            st.rerun()

with col_file:
    uploaded = st.file_uploader("Upload file", key="upload_file")
    if uploaded is not None:
        fn = uploaded.name
        target = os.path.join(UPLOADS_DIR, fn)
        with open(target, "wb") as f:
            f.write(uploaded.getbuffer())
        st.success(f"Saved file: {fn}")
        if st.button("Insert file reference", key=f"insert_file_{fn}"):
            insert = f"[Attached file: {fn}](uploads/{fn})"
            st.session_state["user_input_box"] = (st.session_state.get("user_input_box", "") or "") + " " + insert
            st.experimental_rerun()

with col_audio:
    audio_file = st.file_uploader("Upload audio (wav/mp3)", type=["wav", "mp3", "m4a", "ogg"], key="upload_audio")
    if audio_file is not None:
        fn = audio_file.name
        target = os.path.join(UPLOADS_DIR, fn)
        with open(target, "wb") as f:
            f.write(audio_file.getbuffer())
        st.success(f"Saved audio: {fn}")

        # Transcription attempt (if backend supports it)
        if st.button("Transcribe audio and insert", key=f"transcribe_{fn}"):
            proxy = st.session_state.get("proxy_agent")
            if proxy and hasattr(proxy, "transcribe_audio"):
                try:
                    audio_bytes = audio_file.getvalue()
                    text = proxy.transcribe_audio(audio_bytes, filename=fn)
                    if text:
                        st.session_state["user_input_box"] = (st.session_state.get("user_input_box", "") or "") + " " + text
                        st.success("Transcription inserted into message box.")
                        st.experimental_rerun()
                    else:
                        st.warning("Transcription returned empty text.")
                except Exception as e:
                    st.error(f"Transcription failed: {e}")
            else:
                st.info("No transcription capability found on backend. To transcribe automatically, your proxy agent must implement `transcribe_audio(bytes, filename)`.")

# ---------- Message Input ----------
if current_chat:
    # Ensure the chat input is prefilled with session value if present
    if "user_input_box" not in st.session_state:
        st.session_state["user_input_box"] = ""

    user_input = st.chat_input("Ask me anything...", key="user_input_box")
    if user_input:
        append_message(st.session_state.current_chat_id, "user", user_input)
        st.session_state.user_input = ""  # clear input

        if not st.session_state.backend_initialized:
            st.error(f"Backend not ready: {st.session_state.backend_error}")
        else:
            try:
                with st.spinner("🤔 Thinking..."):
                    response = st.session_state.proxy_agent.process(user_input)
                    assistant_text = response.get("text") if isinstance(response, dict) else str(response)
                    append_message(st.session_state.current_chat_id, "assistant", assistant_text)

                    # Save chat once after appending both messages
                    save_memory(st.session_state.current_chat_id)
            except Exception as e:
                append_message(st.session_state.current_chat_id, "assistant", f"⚠️ Error: {e}")

        st.rerun()
