# assistant_hub/ui/views.py
import streamlit as st
from typing import Optional, Dict

def top_bar():
    """
    Renders the top bar with the app title only.
    """
    st.markdown(
        """
        <style>
        .top-bar {
            display: flex; justify-content: flex-start; align-items: center;
            padding: 10px 20px; background: #0f1724; border-radius: 10px; 
            margin-bottom: 10px; box-shadow: 0 3px 12px rgba(0,0,0,0.3);
        }
        .app-title { color: #e0e0e0; font-size: 20px; font-weight: 600; }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.markdown("<div class='app-title'>Proxi</div>", unsafe_allow_html=True)


def render_save_dialog(chat: Optional[Dict], default_name: str):
    """
    Render a reusable save (rename) dialog for the given chat.

    Returns a dict with keys:
      - saved: bool
      - cancelled: bool
      - new_name: Optional[str] (present when saved is True)
    This function only renders UI and reads widget state; it does not perform saving itself.
    """
    st.warning("⚠️ You have an unsaved conversation. Save it before continuing.")

    # Pre-fill the input with the current title (or default)
    new_name = st.text_input(
        "Enter chat name to save:",
        value=default_name,
        key="views_pending_rename_input",
        max_chars=200
    )

    col_save, col_cancel = st.columns([1, 1])
    with col_save:
        save_clicked = st.button("💾 Save & Continue", key="views_pending_save")
    with col_cancel:
        cancel_clicked = st.button("❌ Cancel", key="views_pending_cancel")

    result = {"saved": False, "cancelled": False, "new_name": None}

    if save_clicked:
        if not new_name or not new_name.strip():
            st.warning("Please enter a valid chat name before continuing.")
        else:
            result["saved"] = True
            result["new_name"] = new_name.strip()

    if cancel_clicked:
        result["cancelled"] = True

    return result


def render_delete_dialog(chat: Optional[Dict]):
    """
    Render a delete confirmation dialog for the given chat.
    Returns: {"confirmed": bool, "cancelled": bool}
    """
    st.error("🗑️ Are you sure you want to delete this conversation? This action cannot be undone.")
    if chat:
        st.write(f"Conversation: **{chat.get('title', 'Untitled Chat')}**")
        st.write(f"Messages: {len(chat.get('messages', []))}")
    else:
        st.write("No conversation selected.")

    col_yes, col_no = st.columns([1, 1])
    with col_yes:
        confirm = st.button("Yes — Delete", key="views_confirm_delete")
    with col_no:
        cancel = st.button("Cancel", key="views_cancel_delete")

    result = {"confirmed": False, "cancelled": False}
    if confirm:
        result["confirmed"] = True
    if cancel:
        result["cancelled"] = True
    return result


def chat_window(chat: Optional[Dict]):
    """Display chat messages in conversation order."""
    st.markdown("<hr/>", unsafe_allow_html=True)
    st.subheader(f"💬 {chat.get('title') if chat else 'No Chat Selected'}")

    if not chat:
        st.info("Start a new chat or select one in the sidebar.")
        return

    for msg in chat.get("messages", []):
        role = msg.get("role")
        text = msg.get("text")
        if role == "user":
            st.chat_message("user").markdown(text)
        else:
            st.chat_message("assistant").markdown(text)
