# assistant_hub/ui/helpers.py
import os
import json
import re
import time
import random
import streamlit as st

MEMORY_DIR = os.path.join(os.path.dirname(__file__), "..", "memory")
if not os.path.exists(MEMORY_DIR):
    os.makedirs(MEMORY_DIR, exist_ok=True)


def _sanitize_filename(name: str) -> str:
    """
    Make a safe filename from an arbitrary chat title.
    Keeps letters, numbers, dot, underscore and hyphen. Replaces others with underscore.
    """
    if not isinstance(name, str):
        name = str(name)
    # replace sequences of disallowed chars with single underscore
    safe = re.sub(r'[^A-Za-z0-9._-]+', '_', name).strip('_')
    return safe or "chat"


# ---------- Chat management helpers ----------

def load_memory():
    """Load saved chats (JSON) from memory directory."""
    files = [f for f in os.listdir(MEMORY_DIR) if f.endswith(".json")]
    chats = []
    for fn in files:
        full = os.path.join(MEMORY_DIR, fn)
        try:
            with open(full, "r", encoding="utf-8") as f:
                data = json.load(f)
                # if title missing, derive from filename (without extension)
                data["title"] = data.get("title", os.path.splitext(fn)[0])
                chats.append(data)
        except Exception as e:
            # don't crash on one bad file — print to stderr for debugging
            print(f"[helpers.load_memory] failed to load {full}: {e}")
            continue
    # sort by id descending (newest first) — keep original behaviour
    chats.sort(key=lambda c: c.get("id", 0), reverse=True)
    return chats


def save_memory(chat_id):
    """Persist a specific chat by ID."""
    try:
        chat = get_chat(chat_id)
        if not chat:
            print(f"[helpers.save_memory] chat id {chat_id} not found in session_state")
            return
        title = chat.get("title", f"chat_{chat_id}")
        safe_title = _sanitize_filename(title)
        file_name = f"{safe_title}_{chat_id}.json"
        target_path = os.path.join(MEMORY_DIR, file_name)

        # remove any existing files for this chat id (prevents duplicates if title changed)
        for fn in os.listdir(MEMORY_DIR):
            if fn.endswith(f"_{chat_id}.json") and fn != file_name:
                try:
                    os.remove(os.path.join(MEMORY_DIR, fn))
                except Exception as e:
                    print(f"[helpers.save_memory] failed to remove old file {fn}: {e}")

        # write the file
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(chat, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[helpers.save_memory] failed to save chat {chat_id}: {e}")


def save_current_chat_to_log():
    """Save current chat to disk and remember last active chat."""
    chat_id = st.session_state.get("current_chat_id")
    if chat_id is None:
        st.warning("No active chat to save.")
        return
    save_memory(chat_id)

    # Save last active chat ID
    try:
        with open(os.path.join(MEMORY_DIR, "last_active_chat.txt"), "w", encoding="utf-8") as f:
            f.write(str(chat_id))
    except Exception as e:
        print(f"[helpers.save_current_chat_to_log] failed to write last_active_chat.txt: {e}")

    st.success("Chat saved successfully.")


def get_chat(chat_id):
    """Return chat dict by ID."""
    for chat in st.session_state.get("chats", []):
        if chat.get("id") == chat_id:
            return chat
    return None


def new_chat(name="Untitled Chat"):
    """Create and activate a new chat.

    Keeps numeric IDs (ms timestamp) but appends a small random suffix to reduce collision risk.
    """
    base = int(time.time() * 1000)
    suffix = random.randint(0, 999)
    new_id = base * 1000 + suffix  # still numeric and increasing
    chat_obj = {
        "id": new_id,
        "title": name,
        "project": "Default",
        "messages": [],
    }
    # ensure chats list exists
    if "chats" not in st.session_state:
        st.session_state["chats"] = []
    st.session_state.chats.insert(0, chat_obj)
    st.session_state.current_chat_id = new_id
    save_memory(new_id)
    return new_id


def append_message(chat_id, role, text):
    """Append a message to a chat."""
    try:
        chat = get_chat(chat_id)
        if not chat:
            print(f"[helpers.append_message] chat id {chat_id} not found")
            return
        chat.setdefault("messages", []).append({
            "role": role,
            "text": text,
            "ts": time.time()
        })
        # persist immediately (keeps behavior same as before)
        save_memory(chat_id)
    except Exception as e:
        print(f"[helpers.append_message] failed to append message to {chat_id}: {e}")
