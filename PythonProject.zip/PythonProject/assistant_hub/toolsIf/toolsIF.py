# assistant_hub/toolsIf/toolsIF.py
from abc import ABC, abstractmethod
import io
import json
import traceback
import matplotlib.pyplot as plt
from contextlib import redirect_stdout, redirect_stderr
from assistant_hub.core.logging_config import logger


class ITool(ABC):
    @abstractmethod
    def run(self, *args, **kwargs):
        pass

    # Alias for compatibility
    def execute(self, *args, **kwargs):
        return self.run(*args, **kwargs)

    def get_description(self) -> str:
        """Return tool description"""
        return "A tool implementation"


class PythonExecutorTool(ITool):
    """Execute arbitrary Python code safely and return output + plots"""

    def run(self, code: str, **kwargs) -> dict:
        result = {"stdout": "", "stderr": "", "error": "", "plots": []}
        stdout_buffer = io.StringIO()
        stderr_buffer = io.StringIO()

        try:
            # Redirect stdout and stderr to capture print outputs
            with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
                # Create isolated local scope
                local_vars = {}

                # Execute code
                exec(code, {"plt": plt, "__builtins__": __builtins__}, local_vars)

                # Capture matplotlib figures (if any)
                figs = [plt.figure(i) for i in plt.get_fignums()]
                for fig in figs:
                    buf = io.BytesIO()
                    fig.savefig(buf, format="png")
                    buf.seek(0)
                    result["plots"].append(buf.read())
                    plt.close(fig)

            result["stdout"] = stdout_buffer.getvalue()
        except Exception as e:
            result["error"] = traceback.format_exc()
        finally:
            result["stderr"] = stderr_buffer.getvalue()

        return result

    def get_description(self) -> str:
        return "Executes Python code safely and captures output/plots"


def load_toolkits():
    """Load and register all available tools for the system"""
    try:
        from assistant_hub.tools.research_tools import (
            WebSearchTool, WebScraperTool, ContentAnalyzerTool, ResearchSummarizerTool
        )
        from assistant_hub.tools.coding_tools import CodeGeneratorTool, CodeExecutionTool, CodeValidatorTool
        from assistant_hub.tools.visualization_tools import ChartGeneratorTool, TableProcessorTool
        from assistant_hub.tools.output_formatter import OutputFormatterTool

        toolkits = {
            "python_exec": PythonExecutorTool(),
            "web_search": WebSearchTool(),
            "web_scraper": WebScraperTool(),
            "content_analyzer": ContentAnalyzerTool(),
            "research_summarizer": ResearchSummarizerTool(),
            "code_generator": CodeGeneratorTool(),
            "code_execution": CodeExecutionTool(),
            "code_validator": CodeValidatorTool(),
            "chart_generator": ChartGeneratorTool(),
            "table_processor": TableProcessorTool(),
            "output_formatter": OutputFormatterTool(),
        }

        logger.info(f"✅ Loaded {len(toolkits)} tools successfully")
        return toolkits

    except Exception as e:
        logger.error(f"❌ Tool loading failed: {e}")
        # Return minimal toolset for basic functionality
        return {
            "python_exec": PythonExecutorTool(),
            "web_search": WebSearchTool(),
            "code_execution": CodeExecutionTool(),
        }