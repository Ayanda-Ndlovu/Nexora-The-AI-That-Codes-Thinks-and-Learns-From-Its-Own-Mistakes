# assistant_hub/toolsIf/interfaces.py
from abc import ABC, abstractmethod

class ITool(ABC):
    """Base interface for all tools"""

    @abstractmethod
    def run(self, *args, **kwargs):
        """Execute the tool's primary function"""
        pass
