# assistant_hub/agentsIf/agentsIF.py
from abc import ABC, abstractmethod
from assistant_hub.agents import (
    CoderAgent,
    PlannerAgent,
    ProxyAgent,
    ResearcherAgent,
    ValidatorAgent,
)
from assistant_hub.core.logging_config import logger

# Minimal interface retained for compatibility
class IAgent(ABC):
    """Common interface for all agents"""

    def __init__(self, name: str, llm=None):
        self.name = name
        self.llm = llm

    @abstractmethod
    def process(self, query: str, context: dict) -> dict:
        pass


def get_agent_class_map():
    """Returns a dictionary mapping agent names to their classes."""
    return {
        "coder": CoderAgent,
        "planner": PlannerAgent,
        "proxy": ProxyAgent,
        "researcher": ResearcherAgent,
        "validator": ValidatorAgent,
    }

