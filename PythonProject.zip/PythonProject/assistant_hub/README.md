==============================
🧠 Proxi – Streamlit AI Assistant Platform
==============================

Proxi is a Streamlit-based AI assistant framework designed with UX simplicity and asynchronous backend coordination.
It was fine-tuned using TinyLlama and built for flexible multi-agent collaboration. Users can interact with intelligent
tools that handle coding, research, visualization, and more — all through a clean and intuitive Streamlit interface.

------------------------------
🚀 Features
------------------------------
• Modular architecture with independent agents (ProxyAgent, ResearchAgent, CodingAgent, etc.).
• Fine-tuned local model (TinyLlama.Q4_K_M.gguf) integrated into backend workflows.
• Streamlit-based interface for simple, responsive user experience.
• Asynchronous backend for smooth multitasking and non-blocking operations.
• Persistent memory and session storage for continuous conversations.
• Easy model fine-tuning and extension through the training module.

------------------------------
📁 Project Structure
------------------------------
assistant_hub/
│
├── fine_tuned_models/
│   ├── ModelFile
│   └── Tinyllama.Q4_K_M.gguf
│
├── memory/
│
├── tools/
│   ├── coding_tools.py
│   ├── research_tools.py
│   ├── visualization_tools.py
│   └── web_tools.py
│
├── training/
│   ├── fine_tuning_manager.py
│   ├── collector.py
│   └── training_data/
│
├── ui/
│   ├── helpers.py
│   ├── views.py
│   └── Logo.jpeg
│
├── run_assistant.py
└── Streamlit_app.py

------------------------------
⚙️ Installation
------------------------------
1️⃣ Install dependencies:
    pip install -r requirements.txt

2️⃣ Run the Streamlit app:
    streamlit run assistant_hub/Streamlit_app.py

3️⃣ Open the Streamlit link in your browser and start interacting with Proxi.

------------------------------
🧩 Core Components
------------------------------
• Streamlit_app.py – Entry point for the Proxi UI and backend initialization.
• run_assistant.py – Manages and coordinates all backend agents.
• helpers.py / views.py – Handles user interface and chat interactions.
• fine_tuning_manager.py – Fine-tuning logic and data collection for custom models.
• research_tools.py / coding_tools.py – Specialized modules for intelligent tasks.

------------------------------
🧠 Tech Stack
------------------------------
Frontend: Streamlit
Backend: Python (Async architecture)
Models: TinyLlama (fine-tuned as Proxi)
Storage: Local session memory
Libraries: LangChain, PyPDF2, JSON, AsyncIO, OS

------------------------------
🧑‍🎓 Credits
------------------------------.
Proxi was fine-tuned from TinyLlama and serves as a demonstration of seamless UX design and asynchronous AI coordination.
