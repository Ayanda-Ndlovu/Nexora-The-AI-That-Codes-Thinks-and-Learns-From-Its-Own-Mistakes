# assistant_hub/core/config.py - UPDATED VERSION

import logging
from typing import Dict, Optional
from dataclasses import dataclass, field
from enum import Enum


class FineTuningMethod(Enum):
    LORA = "lora"
    FULL = "full"
    PREFIX_TUNING = "prefix_tuning"


@dataclass
class FineTuningConfig:
    method: FineTuningMethod = FineTuningMethod.LORA
    learning_rate: float = 1e-4
    num_epochs: int = 3
    batch_size: int = 4
    max_seq_length: int = 2048
    dataset_path: str = "assistant_hub/training/training_data/"
    output_dir: str = "assistant_hub/training/fine_tuned_models/"
    validation_split: float = 0.1

    def __post_init__(self):
        if self.learning_rate <= 0:
            raise ValueError("Learning rate must be positive")
        if self.num_epochs <= 0:
            raise ValueError("Number of epochs must be positive")
        if self.batch_size <= 0:
            raise ValueError("Batch size must be positive")
        if not 0 <= self.validation_split <= 1:
            raise ValueError("Validation split must be between 0 and 1")


@dataclass
class LLMConfig:
    model: str = "tinyllama"
    temperature: float = 0.2
    max_tokens: int = 2000
    use_langchain: bool = True
    fine_tuning: Optional[FineTuningConfig] = None

    def __post_init__(self):
        if not self.model:
            raise ValueError("Model name cannot be empty")
        if not 0 <= self.temperature <= 1:
            raise ValueError("Temperature must be between 0 and 1")


# assistant_hub/core/config.py - ADD OPTIMIZED CONFIG

# assistant_hub/core/config.py - USE FASTER MODEL

# assistant_hub/core/config.py - MAXIMUM PERFORMANCE

class Config:
    """
    Singleton class for global configuration settings.
    """
    _instance: 'Config' = None
    _llm_configs: Dict[str, LLMConfig] = {}
    LOG_LEVEL: int = logging.INFO
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    LLM_VERBOSE: bool = False
    LLM_TIMEOUT: int = 120  # Very aggressive timeout
    LLM_MAX_RETRIES: int = 2

    @classmethod
    def _initialize_defaults(cls):
        # Maximum performance defaults
        try:
            cls._llm_configs = {
                "proxy": LLMConfig(model="tinyllama", temperature=0.1, max_tokens=60, use_langchain=False),
                "planner": LLMConfig(model="tinyllama", temperature=0.2, max_tokens=70, use_langchain=False),
                "researcher": LLMConfig(model="tinyllama", temperature=0.2, max_tokens=80, use_langchain=False),
                "coder": LLMConfig(model="tinyllama-coder-final", temperature=0.1, max_tokens=100, use_langchain=False),
                "validator": LLMConfig(model="tinyllama", temperature=0.1, max_tokens=50, use_langchain=False)
            }
        except Exception as e:
            logging.error(f"Configuration initialization error: {e}")
            raise
    def get_llm_config(self, agent_type: str) -> LLMConfig:
        config = self._llm_configs.get(agent_type)
        if not config:
            logging.warning(f"No LLM config found for '{agent_type}'; returning default LLMConfig()")
            return LLMConfig()
        return config

    def set_llm_config(self, agent_type: str, config: LLMConfig):
        # validate by calling __post_init__
        config.__post_init__()
        self._llm_configs[agent_type] = config

    def enable_fine_tuning(self, agent_type: str, fine_tuning_config: FineTuningConfig):
        current_config = self.get_llm_config(agent_type)
        current_config.fine_tuning = fine_tuning_config
        self.set_llm_config(agent_type, current_config)

    def disable_fine_tuning(self, agent_type: str):
        current_config = self.get_llm_config(agent_type)
        current_config.fine_tuning = None
        self.set_llm_config(agent_type, current_config)