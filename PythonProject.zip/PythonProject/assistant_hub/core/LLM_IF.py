from abc import ABC, abstractmethod
from typing import Any, Dict, List
from dataclasses import dataclass
from assistant_hub.core.config import LLMConfig

# The agent code expects an object with a generate(...) method that returns an object similar to LLMResult.
# Keep the interface minimal and compatible with your BaseAgent usage.

class ILLM(ABC):
    @abstractmethod
    def generate(self, prompts: List[List[Any]], **kwargs) -> Any:
        """Generate LLM outputs. Must be compatible with BaseAgent expectations."""
        raise NotImplementedError

    @abstractmethod
    def generate_text(self, prompt: str, config: LLMConfig) -> str:
        """Convenience wrapper to generate raw text for a prompt."""
        raise NotImplementedError
