# assistant_hub/core/dependency_injector.py - CLEAN VERSION
from typing import Dict, Any


class DependencyContainer:
    """
    A simple dependency container used throughout the project.
    """

    def __init__(self):
        self._factories: Dict[Any, Any] = {}
        self._singletons: Dict[Any, Any] = {}

    def register(self, key: Any, implementation: Any, singleton: bool = False):
        """
        Register an implementation. `key` can be a string or a type/class.
        If singleton=True, the implementation (or factory) will be treated as a singleton.
        """
        if singleton:
            self._singletons[key] = implementation
        else:
            self._factories[key] = implementation

    def resolve(self, key: Any) -> Any:
        """
        Resolve a dependency by key. If the stored value is callable we call it to produce a new instance.
        """
        # Singletons have highest precedence
        if key in self._singletons:
            impl = self._singletons[key]
            if callable(impl) and not isinstance(impl, type):
                # factory function producing a singleton instance
                instance = impl()
                self._singletons[key] = instance
                return instance
            return impl if not callable(impl) else impl()

        if key in self._factories:
            impl = self._factories[key]
            return impl() if callable(impl) else impl

        # Try to find by class name if someone passed a string accidentally
        if isinstance(key, str):
            for registered_key in list(self._singletons.keys()) + list(self._factories.keys()):
                if getattr(registered_key, "__name__", str(registered_key)) == key:
                    return self.resolve(registered_key)

        raise ValueError(f"Dependency not registered: {key}")


# Global container instance (import this from other modules)
container = DependencyContainer()