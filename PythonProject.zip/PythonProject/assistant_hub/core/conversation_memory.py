from typing import List, Dict, Any
from datetime import datetime


class ConversationMemory:
    """Simple conversation memory helper storing recent exchanges."""

    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.history: List[Dict[str, Any]] = []

    def add_exchange(self, user_input: str, assistant_response: str, agent_used: str = None):
        exchange = {
            'timestamp': datetime.now().isoformat(),
            'user': user_input,
            'assistant': assistant_response,
            'agent': agent_used,
            'tokens': len(user_input) + len(assistant_response)
        }
        self.history.append(exchange)
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

    def get_recent_history(self, num_exchanges: int = 3) -> List[Dict[str, Any]]:
        return self.history[-num_exchanges:]

    def get_full_history(self) -> List[Dict[str, Any]]:
        return list(self.history)

    def get_summary(self) -> str:
        if not self.history:
            return "No conversation history yet."
        recent = self.get_recent_history(3)
        summary_lines = [f"Recent conversation ({len(recent)} exchanges):"]
        for i, ex in enumerate(recent, 1):
            u = ex.get('user', '')[:120]
            a = ex.get('assistant', '')[:120]
            summary_lines.append(f"{i}. You: {u} -> Assistant: {a}")
        return "\n".join(summary_lines)

    def clear(self):
        self.history.clear()

    def to_context(self) -> Dict[str, Any]:
        return {
            'conversation_history': self.get_recent_history(3),
            'conversation_summary': self.get_summary(),
            'total_exchanges': len(self.history)
        }
