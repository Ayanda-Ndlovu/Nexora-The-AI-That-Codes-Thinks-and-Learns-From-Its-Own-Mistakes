# assistant_hub/core/ollama_llm.py - IMPROVED VERSION

import requests
import json
import time
from typing import List, Any
from assistant_hub.core.LLM_IF import ILLM
from assistant_hub.core.config import LLMConfig, Config
from assistant_hub.core.logging_config import logger


class OllamaLLM(ILLM):
    def __init__(self, base_url: str = None):
        config = Config()

        if base_url is None:
            base_url = config.OLLAMA_BASE_URL

        self.base_url = base_url.rstrip('/')
        self.verbose = getattr(config, 'LLM_VERBOSE', False)
        self.timeout = 300  # ✅ INCREASED TIMEOUT
        self.max_retries = 5  # ✅ ADDED RETRIES

        # Use tinyllama for maximum speed
        self.model = "tinyllama"
        logger.info(f"OllamaLLM using model: {self.model}")

    def generate(self, prompts: List[List[Any]], **kwargs) -> dict:
        """
        Improved generation with better timeout handling
        """
        for attempt in range(self.max_retries + 1):
            try:
                # Extract prompt text
                if prompts and len(prompts) > 0 and len(prompts[0]) > 0:
                    prompt_obj = prompts[0][0]
                    prompt_text = str(prompt_obj)
                else:
                    prompt_text = ""

                # Enhanced payload with configurable parameters
                payload = {
                    "model": self.model,
                    "prompt": prompt_text,
                    "temperature": kwargs.get('temperature', 0.2),
                    "max_tokens": kwargs.get('max_tokens', 1000),  # ✅ INCREASED TOKENS
                    "stream": False
                }

                start_time = time.time()
                response = requests.post(
                    f"{self.base_url}/api/generate",
                    json=payload,
                    timeout=self.timeout
                )

                response_time = time.time() - start_time

                if response.status_code != 200:
                    logger.warning(f"Ollama API error: {response.status_code}")
                    if attempt < self.max_retries:
                        logger.info(f"Retrying... ({attempt + 1}/{self.max_retries})")
                        time.sleep(1)
                        continue
                    return {"text": "Service temporarily unavailable.", "raw": {}}

                data = response.json()
                text = data.get("response", "No response generated")

                logger.info(f"Ollama response in {response_time:.2f}s: '{text[:50]}...'")
                return {"text": text, "raw": data}

            except requests.exceptions.Timeout:
                logger.warning(f"Ollama request timed out (attempt {attempt + 1})")
                if attempt < self.max_retries:
                    logger.info(f"Retrying... ({attempt + 1}/{self.max_retries})")
                    time.sleep(1)
                    continue
                # Provide a helpful fallback response instead of error
                return self._get_fallback_response(prompts)
            except requests.exceptions.ConnectionError:
                logger.error("Cannot connect to Ollama")
                return {"text": "AI service unavailable. Please check if Ollama is running.", "raw": {}}
            except Exception as e:
                logger.error(f"Ollama error: {e}")
                if attempt < self.max_retries:
                    logger.info(f"Retrying... ({attempt + 1}/{self.max_retries})")
                    time.sleep(1)
                    continue
                return {"text": "Temporary service issue. Please try again.", "raw": {}}

    def _get_fallback_response(self, prompts: List[List[Any]]) -> dict:
        """Provide intelligent fallback responses when Ollama times out"""
        if not prompts or not prompts[0]:
            return {"text": "Please provide a question or request.", "raw": {}}

        prompt_text = str(prompts[0][0]).lower()

        # Enhanced keyword-based fallback responses
        if any(word in prompt_text for word in ['hello', 'hi', 'hey']):
            return {"text": "Hello! How can I help you today?", "raw": {}}
        elif any(word in prompt_text for word in ['code', 'python', 'program', 'function', 'sort']):
            return self._get_code_fallback(prompt_text)
        elif any(word in prompt_text for word in ['research', 'about', 'what is', 'tell me about']):
            return {"text": "I can research topics for you. Please specify what you'd like to know.", "raw": {}}
        elif any(word in prompt_text for word in ['plot', 'chart', 'graph']):
            return self._get_plot_fallback(prompt_text)
        else:
            return {"text": "I'm here to help! Please ask your question.", "raw": {}}

    def _get_code_fallback(self, prompt_text: str) -> dict:
        """Provide code-specific fallback responses"""
        if 'sort' in prompt_text and 'array' in prompt_text:
            sort_code = '''def sort_array(arr):
    """Sort an array of integers in ascending order"""
    return sorted(arr)

# Example usage:
numbers = [5, 2, 8, 1, 9]
sorted_numbers = sort_array(numbers)
print(f"Original: {numbers}")
print(f"Sorted: {sorted_numbers}")'''
            return {"text": f"Here's a Python function to sort an array:\n\n```python\n{sort_code}\n```", "raw": {}}
        elif 'fibonacci' in prompt_text:
            fib_code = '''def fibonacci(n):
    """Generate Fibonacci sequence up to n terms"""
    sequence = []
    a, b = 0, 1
    for _ in range(n):
        sequence.append(a)
        a, b = b, a + b
    return sequence

# Example usage:
print(fibonacci(10))  # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]'''
            return {"text": f"Here's a Python function for Fibonacci sequence:\n\n```python\n{fib_code}\n```", "raw": {}}
        else:
            return {"text": "I can help with coding questions. Please try rephrasing your request.", "raw": {}}

    def _get_plot_fallback(self, prompt_text: str) -> dict:
        """Provide plot-specific fallback responses"""
        if 'x=' in prompt_text and 'y=' in prompt_text:
            plot_code = '''import matplotlib.pyplot as plt

x = [1, 3, 2, 4, 5]
y = [1, 2, 3, 4, 5]

plt.plot(x, y, marker='o')
plt.xlabel('X values')
plt.ylabel('Y values')
plt.title('Line Plot')
plt.grid(True)
plt.show()'''
            return {"text": f"Here's Python code to create your plot:\n\n```python\n{plot_code}\n```", "raw": {}}
        else:
            return {"text": "I can help create plots. Please specify x and y values.", "raw": {}}

    def generate_text(self, prompt: str, config: LLMConfig) -> str:
        result = self.generate(prompts=[[prompt]], temperature=config.temperature, max_tokens=config.max_tokens)
        return result.get("text", "")