import logging
from typing import Dict, Any, List, Type
from langchain_core.messages import HumanMessage
from assistant_hub.agents import CoderAgent, ResearcherAgent, PlannerAgent, ValidatorAgent, ProxyAgent
from assistant_hub.core.LLM_IF import ILLM, LLMConfig
from assistant_hub.core.dependency_injector import DependencyContainer, container
from assistant_hub.core.config import Config, FineTuningConfig
from assistant_hub.training.fine_tuning_manager import FineTuningManager
from assistant_hub.tools.langchain_tools import CompatibleToolWrapper  # For type hint

logger = logging.getLogger(__name__)


# =====================================================
# 1. LangChain LLM Wrapper
# =====================================================
class LangChainLLMWrapper(ILLM):
    """
    Wrap LangChain chat LLMs to comply with ILLM interface.
    This allows agents to use a standard `generate` method regardless of the
    underlying LLM implementation (LangChain, custom, etc.).
    """

    def __init__(self, langchain_llm):
        self.langchain_llm = langchain_llm

    def generate(self, prompts: List[List[Any]], **kwargs) -> Dict[str, Any]:
        """Convert ILLM list-of-lists prompt format to LangChain invocation."""
        try:
            # Assume the first element of the first list is the message/prompt
            messages = prompts[0] if prompts else [HumanMessage(content="")]

            # Apply temperature if present in kwargs and supported by the underlying LLM
            temp = kwargs.get('temperature')
            if temp is not None and hasattr(self.langchain_llm, 'temperature'):
                # Note: Directly modifying an instance attribute might not always work
                # for thread safety or stateless models, but is a simple way for demos.
                self.langchain_llm.temperature = temp

            response = self.langchain_llm.invoke(messages)

            # Extract content from the response object
            response_text = response.content if hasattr(response, "content") else str(response)

            # Return a dict to match the simple ILLM return type defined elsewhere
            return {"text": response_text}

        except Exception as e:
            logger.error(f"LangChain generation error: {e}")
            return {"text": f"Error: {str(e)}"}

    def generate_text(self, prompt: str, config: LLMConfig) -> str:
        """Simple text generation method for direct use."""
        result = self.generate([[HumanMessage(content=prompt)]],
                               model=config.model,
                               temperature=config.temperature)
        return result.get("text", f"Error: Failed to generate text for {config.model}")


# =====================================================
# 2. LLM Factory
# =====================================================
# assistant_hub/core/factory.py - FIXED LLM CREATION

# assistant_hub/core/factory.py - FIX LANGCHAIN DEPRECATION

# assistant_hub/core/factory.py - FIX REGISTRATION METHODS

# assistant_hub/core/factory.py - FIX CONFIG ISSUE

class LLMFactory:
    """Factory for creating LLM interfaces based on configuration."""

    def __init__(self):
        self._llms: Dict[str, Type[ILLM]] = {}
        self._langchain_models: Dict[str, Type[Any]] = {}
        self._register_default_llms()

    def _register_default_llms(self):
        """Register default LLM classes and names."""
        try:
            from assistant_hub.core.ollama_llm import OllamaLLM
            self.register_llm("ollama", OllamaLLM)
            self.register_llm("tinyllama", OllamaLLM)
            self.register_llm("gemma:2b", OllamaLLM)
            self.register_llm("codellama", OllamaLLM)
        except ImportError as e:
            logger.warning(f"Could not import OllamaLLM: {e}")

    def register_llm(self, name: str, llm_class: Type[ILLM]):
        """Register a custom ILLM implementation."""
        self._llms[name] = llm_class

    def register_langchain_model(self, model_name: str, llm_class: Type[Any]):
        """Register a LangChain-compatible model by its name."""
        self._langchain_models[model_name] = llm_class

    def create_llm(self, config: LLMConfig) -> ILLM:
        """Instantiate an LLM based on a configuration object."""
        try:
            config_manager = Config()

            if config.use_langchain:
                # Try to find a registered LangChain model wrapper
                llm_class = self._langchain_models.get(config.model)
                if llm_class:
                    logger.info(f"Creating LangChain LLM: {config.model}")
                    try:
                        llm_instance = llm_class(
                            base_url=config_manager.OLLAMA_BASE_URL,
                            model=config.model,
                            temperature=config.temperature
                        )
                        return LangChainLLMWrapper(llm_instance)
                    except Exception as e:
                        logger.warning(f"LangChain LLM failed, falling back to direct Ollama: {e}")
                        config.use_langchain = False

            # Handle custom ILLM implementation or fallback
            if config.model in self._llms:
                logger.info(f"Creating Custom ILLM: {config.model}")
                return self._llms[config.model](base_url=config_manager.OLLAMA_BASE_URL)

            # Final fallback: Use OllamaLLM directly
            logger.info(f"Using direct OllamaLLM for: {config.model}")
            from assistant_hub.core.ollama_llm import OllamaLLM
            return OllamaLLM(base_url=config_manager.OLLAMA_BASE_URL)

        except Exception as e:
            logger.error(f"Error creating LLM: {e}")
            # Ultimate fallback
            from assistant_hub.core.ollama_llm import OllamaLLM
            return OllamaLLM()

    def get_llm_with_fallback(self, agent_type: str) -> ILLM:
        """
        Attempts to create an LLM instance for a specific agent type.
        If it fails, it falls back to a safe default.
        """
        try:
            from assistant_hub.core.config import Config
            config = Config().get_llm_config(agent_type)
            return self.create_llm(config)
        except Exception as e:
            logger.error(f"Failed to create primary LLM for '{agent_type}': {e}")
            # Fallback to direct OllamaLLM
            try:
                from assistant_hub.core.ollama_llm import OllamaLLM
                logger.info(f"Using direct OllamaLLM fallback for '{agent_type}'")
                return OllamaLLM()
            except Exception as fallback_error:
                logger.error(f"Fallback also failed: {fallback_error}")
                raise
# =====================================================
# 3. Base Tool Factory
# =====================================================
# assistant_hub/core/factory.py - FIXED TOOL REGISTRATION

class ToolFactory:
    """Factory to create tools dynamically."""

    def __init__(self, container):
        self.container = container

    def create_tool(self, tool_name: str) -> Any:
        tool_name = tool_name.lower()
        if tool_name == "web_search":
            from assistant_hub.tools.research_tools import WebSearchTool
            return WebSearchTool()
        elif tool_name == "web_scraper":
            from assistant_hub.tools.research_tools import WebScraperTool
            return WebScraperTool()
        elif tool_name == "content_analyzer":
            from assistant_hub.tools.research_tools import ContentAnalyzerTool
            return ContentAnalyzerTool()
        elif tool_name == "table_processor":
            from assistant_hub.tools.research_tools import TableProcessorTool
            return TableProcessorTool()
        elif tool_name == "summarizer":
            from assistant_hub.tools.research_tools import SummarizerTool
            return SummarizerTool()
        else:
            raise ValueError(f"Unknown tool: {tool_name}")
# =====================================================
# 4. LangChain Tool Factory (Wraps Tools for LLM Function Calling)
# =====================================================
class LangChainToolFactory(ToolFactory):
    """
    Factory for creating LangChain-compatible tool wrappers.
    These tools are used for function calling with LLMs.
    """

    def __init__(self):
        # Stores CompatibleToolWrapper classes
        self._tool_wrappers: Dict[str, Type[CompatibleToolWrapper]] = {}
        self._register_default_wrappers()

    def _register_default_wrappers(self):
        """Register default tool wrappers for LangChain compatibility."""
        # Lazy import of LangChain wrappers
        try:
            from assistant_hub.tools.langchain_tools import (
                WebSearchToolWrapper,
                ContentAnalyzerToolWrapper,
                ResearchSummarizerToolWrapper,
                CodeGeneratorToolWrapper,
                ChartGeneratorToolWrapper,
                TableProcessorToolWrapper,
                CodeValidatorToolWrapper,
                OutputFormatterToolWrapper,
                CodeExecutionToolWrapper
            )

            # Register wrappers by their base tool name
            self.register_tool_wrapper('web_search', WebSearchToolWrapper)
            self.register_tool_wrapper('content_analyzer', ContentAnalyzerToolWrapper)
            self.register_tool_wrapper('research_summarizer', ResearchSummarizerToolWrapper)
            self.register_tool_wrapper('code_generator', CodeGeneratorToolWrapper)
            self.register_tool_wrapper('code_execution', CodeExecutionToolWrapper)
            self.register_tool_wrapper('code_validator', CodeValidatorToolWrapper)
            self.register_tool_wrapper('chart_generator', ChartGeneratorToolWrapper)
            self.register_tool_wrapper('table_processor', TableProcessorToolWrapper)
            self.register_tool_wrapper('output_formatter', OutputFormatterToolWrapper)
        except ImportError as e:
            logger.warning(f"Failed to load some LangChain tool wrappers: {e}")

    def register_tool_wrapper(self, name: str, tool_wrapper_class: Type[CompatibleToolWrapper]):
        """Register a LangChain-compatible tool wrapper."""
        self._tool_wrappers[name] = tool_wrapper_class

    def create_tool(self, name: str) -> CompatibleToolWrapper:
        """Instantiate a LangChain tool wrapper by name."""
        tool_class = self._tool_wrappers.get(name)
        if not tool_class:
            raise ValueError(f"LangChain Tool Wrapper '{name}' not registered.")
        return tool_class()

    def get_all_tools(self) -> Dict[str, CompatibleToolWrapper]:
        """Returns instantiated versions of all registered tool wrappers."""
        return {name: self.create_tool(name) for name in self._tool_wrappers}

    def get_langchain_tools(self) -> List[CompatibleToolWrapper]:
        """Returns a list of all instantiated tools compatible with LangChain."""
        return list(self.get_all_tools().values())


# =====================================================
# 5. Dependency Initializer
# =====================================================
# In assistant_hub/core/factory.py - UPDATE THE DEPENDENCY INITIALIZATION

# In factory.py - UPDATE the initialize_dependencies function
def initialize_dependencies() -> DependencyContainer:
    """
    Initializes and registers all core services and factories with the DependencyContainer.
    """
    try:
        # Register Configuration Singleton
        config_singleton = Config()
        container.register('Config', config_singleton, singleton=True)

        # Register Factories
        llm_factory = LLMFactory()
        container.register('LLMFactory', llm_factory, singleton=True)

        # LAZY IMPORTS for tools to avoid circular dependencies
        from assistant_hub.tools.research_tools import (
            WebSearchTool, WebScraperTool, ContentAnalyzerTool, ResearchSummarizerTool
        )
        from assistant_hub.tools.visualization_tools import TableProcessorTool
        from assistant_hub.tools.research_strategies import ResearchStrategy  # CHANGED IMPORT PATH

        # Register tools directly
        container.register('WebSearchTool', WebSearchTool(), singleton=True)
        container.register('WebScraperTool', WebScraperTool(), singleton=True)
        container.register('ContentAnalyzerTool', ContentAnalyzerTool(), singleton=True)
        container.register('ResearchSummarizerTool', ResearchSummarizerTool(), singleton=True)
        container.register('TableProcessorTool', TableProcessorTool(), singleton=True)

        # Register ToolFactory
        tool_factory = ToolFactory(container)
        container.register('ToolFactory', tool_factory, singleton=True)

        # Register ResearchStrategy
        research_strategy = ResearchStrategy(tool_factory)  # NOW IT SHOULD WORK
        container.register('ResearchStrategy', research_strategy, singleton=True)

        # Register LangChainToolFactory
        langchain_tool_factory = LangChainToolFactory()
        container.register('LangChainToolFactory', langchain_tool_factory, singleton=True)

        # Register AgentFactory
        agent_factory = AgentFactory()
        container.register('AgentFactory', agent_factory, singleton=True)

        # Register Fine-Tuning Manager
        fine_tuning_config = FineTuningConfig()
        fine_tuning_manager = FineTuningManager(fine_tuning_config)
        container.register('FineTuningManager', fine_tuning_manager, singleton=True)

        logger.info("✅ All dependencies initialized successfully with actual fine-tuning")
        return container
    except Exception as e:
        logger.error(f"❌ Failed to initialize dependencies: {e}")
        raise
# =====================================================
# 6. Backwards Compatibility Helper
# =====================================================
# The logic below ensures compatibility with older code that might expect a simple
# factory method to create a default LLM instance without relying on the DI container.
def _create_default_llm_instance():
    """
    Create a default LLM instance using the project's LLMFactory registrations.
    """
    try:
        factory = LLMFactory()
        # Try to return a sensible default if present
        return factory.get_llm_with_fallback("default")  # Use a generic key or 'tinyllama'
    except Exception as e:
        logger.error(f"Failed to create default LLM instance: {e}")
        return None


if not hasattr(LLMFactory, "create_default"):
    # Attach as a static helper for compatibility
    setattr(LLMFactory, "create_default", staticmethod(lambda: _create_default_llm_instance()))


# =====================================================
# 3. Agent Factory
# =====================================================
class AgentFactory:
    """
    Factory for creating and initializing agent instances.
    It resolves necessary dependencies (LLM, Tools) from the container.
    """

    def __init__(self):
        # Resolve necessary factories/dependencies once at startup
        self.llm_factory = container.resolve('LLMFactory')
        self.tool_factory = container.resolve('LangChainToolFactory')  # Use LangChainToolFactory for agents

    def create_agent(self, agent_name: str):
        """Creates a specific agent instance."""

        # Determine the correct LLM configuration for this agent type
        # We use the 'get_llm_with_fallback' method defined in LLMFactory
        llm_instance = self.llm_factory.get_llm_with_fallback(agent_name.lower())

        # Pass the LLM instance and the ToolFactory to the agent constructor
        # NOTE: Your agent constructors in base_agent.py might not accept tool_factory.
        # This implementation assumes they *do* or are initialized to resolve tools internally.
        # Since proxy_agent.py needs to see all agents, we list them here.
        if agent_name.lower() == "coderagent" or agent_name.lower() == "coder":
            return CoderAgent(name="coder", llm_interface=llm_instance, tool_factory=self.tool_factory)

        elif agent_name.lower() == "researcheragent" or agent_name.lower() == "researcher":
            return ResearcherAgent(name="researcher", llm_interface=llm_instance, tool_factory=self.tool_factory)

        elif agent_name.lower() == "planneragent" or agent_name.lower() == "planner":
            return PlannerAgent(name="planner", llm_interface=llm_instance, tool_factory=self.tool_factory)

        elif agent_name.lower() == "validatoragent" or agent_name.lower() == "validator":
            return ValidatorAgent(name="validator", llm_interface=llm_instance, tool_factory=self.tool_factory)

        elif agent_name.lower() == "proxyagent" or agent_name.lower() == "proxy":
            # ProxyAgent often doesn't need all tools directly, but uses the LLM
            return ProxyAgent(name="proxy", llm_interface=llm_instance, tool_factory=self.tool_factory)

        else:
            raise ValueError(f"Unknown agent type requested: {agent_name}")

    def get_all_agents(self) -> Dict[str, Any]:
        """Returns all instantiated agents as a dictionary {name: instance}."""
        agent_names = ["coder", "planner", "researcher", "validator", "proxy"]  # Must match names in coordinator
        return {name: self.create_agent(name) for name in agent_names}