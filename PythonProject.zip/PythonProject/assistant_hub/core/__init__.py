# assistant_hub/core/__init__.py

# Import only lightweight dependencies first
from .config import Config, LLMConfig, FineTuningConfig, FineTuningMethod
from .dependency_injector import DependencyContainer, container
from .LLM_IF import ILLM, LLMConfig as BaseLLMConfig
from .ollama_llm import OllamaLLM
from .conversation_memory import ConversationMemory

# Lazy import heavy factory module to prevent circular import issues
def _load_factories():
    from .factory import LLMFactory, LangChainToolFactory, AgentFactory, initialize_dependencies
    globals().update({
        "LLMFactory": LLMFactory,
        "LangChainToolFactory": LangChainToolFactory,
        "AgentFactory": AgentFactory,
        "initialize_dependencies": initialize_dependencies,
    })

_load_factories()

__all__ = [
    'Config', 'LLMConfig', 'FineTuningConfig', 'FineTuningMethod',
    'DependencyContainer', 'container',
    'LLMFactory', 'LangChainToolFactory', 'AgentFactory', 'initialize_dependencies',
    'ILLM', 'BaseLLMConfig', 'OllamaLLM', 'ConversationMemory'
]
