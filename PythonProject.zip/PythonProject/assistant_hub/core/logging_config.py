import logging
import sys
from typing import Any
from assistant_hub.core.config import Config


# Configure a simple global logger used across the project
class ToolLogger:
    def __init__(self, name: str = "AssistantHub"):
        self.logger = logging.getLogger(name)
        self.config = Config()
        self._setup_logger()

    def _setup_logger(self):
        if not self.logger.handlers:
            self.logger.setLevel(self.config.LOG_LEVEL)
            ch = logging.StreamHandler(sys.stdout)
            ch.setLevel(self.config.LOG_LEVEL)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            ch.setFormatter(formatter)
            self.logger.addHandler(ch)

    # FIX: Explicitly added the debug method
    def debug(self, msg: str, **kwargs):
        self.logger.debug(msg, extra=kwargs)

    def info(self, msg: str, **kwargs):
        self.logger.info(msg, extra=kwargs)

    def warning(self, msg: str, **kwargs):
        self.logger.warning(msg, extra=kwargs)

    def error(self, msg: str, **kwargs):
        self.logger.error(msg, extra=kwargs)

    def exception(self, msg: str, **kwargs):
        """Log an exception with stack trace."""
        self.logger.exception(msg, **kwargs)

    # Convenience for agent activity logging
    def agent_activity(self, actor: str, action: str, details: str = ""):
        self.logger.info(f"[{actor}] {action} {details}")


# ✅ Instantiate the logger first
logger = ToolLogger()

# ✅ Then patch missing methods safely
if not hasattr(logger.logger, "debug"):
    # Ensure debug behaves like info if not defined
    def _debug(msg: str, **kwargs):
        logger.info(msg, **kwargs)
    logger.logger.debug = _debug
