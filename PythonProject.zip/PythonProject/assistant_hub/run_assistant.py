# assistant_hub/run_assistant.py - UPDATED WITH AUTOCODING

import time
from assistant_hub.core.logging_config import logger

# Lazy import AutoCodingAgent
AUTO_CODER_LOADED = False
auto_coder = None


def get_default_llm_interface():
    """Get default LLM interface with fallback"""
    try:
        from assistant_hub.core.factory import LLMFactory
        factory = LLMFactory()
        return factory.get_llm_with_fallback("proxy")
    except Exception as e:
        logger.error(f"LLM creation failed: {e}")

        class MockLLM:
            def generate(self, prompts, **kwargs):
                return {"text": "Hello! How can I assist you?", "raw": {}}

            def generate_text(self, prompt, config):
                return "Hello! How can I assist you?"

        return MockLLM()


def initialize_system():
    """Initialize assistant system with agents and coordinator"""
    logger.info("🚀 Initializing Assistant System...")

    from assistant_hub.core.agent_coordinator import AgentCoordinator
    from assistant_hub.core.factory import initialize_dependencies
    from assistant_hub.agentsIf.agentsIF import get_agent_class_map
    from assistant_hub.toolsIf.toolsIF import load_toolkits

    try:
        container = initialize_dependencies()
    except Exception as e:
        logger.warning(f"Dependency injection failed: {e}")
        container = None

    tools = load_toolkits()
    logger.info(f"🛠️ Loaded {len(tools)} tools")

    llm_interface = get_default_llm_interface()

    agents = {}
    agents_map = get_agent_class_map()
    for name, AgentClass in agents_map.items():
        if name != "proxy":
            try:
                agents[name] = AgentClass(name=name, llm_interface=llm_interface)
            except Exception as e:
                logger.error(f"Failed to create agent {name}: {e}")

    coordinator = AgentCoordinator(agents=agents, tools=tools)

    ProxyAgentClass = agents_map.get("proxy")
    if ProxyAgentClass:
        proxy_agent = ProxyAgentClass(name="proxy", llm_interface=llm_interface,
                                      coordinator=coordinator, agents=agents)
        agents["proxy"] = proxy_agent
        coordinator.agents.update(agents)
    else:
        raise RuntimeError("ProxyAgent class not found in agent map")

    return coordinator, agents, proxy_agent


def main():
    """Run assistant in interactive query mode with AutoCodingAgent"""
    global AUTO_CODER_LOADED, auto_coder

    try:
        coordinator, agents, proxy_agent = initialize_system()
        logger.info("🧠 Assistant ready! Type 'exit' to quit.")

        # Lazy load AutoCodingAgent
        if not AUTO_CODER_LOADED:
            try:
                from assistant_hub.agents.code_validation_loop import AutoCodingAgent
                auto_coder = AutoCodingAgent(max_attempts=5)
                AUTO_CODER_LOADED = True
                logger.info("🤖 AutoCodingAgent loaded for code generation")
            except Exception as e:
                logger.warning(f"Failed to load AutoCodingAgent: {e}")
                auto_coder = None

        while True:
            user_input = input("\nYou: ").strip()
            if user_input.lower() in {"exit", "quit", "bye"}:
                logger.info("👋 Exiting assistant...")
                break

            if not user_input:
                continue

            start_time = time.time()
            try:
                # Detect code generation requests
                if auto_coder and any(keyword in user_input.lower() for keyword in ["code", "function", "script", "python"]):
                    logger.info("[Assistant] Routing request to AutoCodingAgent for code generation")
                    # Optional: Define test cases based on prompt
                    test_cases = []  # Could be filled dynamically later
                    result = auto_coder.generate_code(user_input, test_cases=test_cases)
                    assistant_text = result.get("final_code", "No code generated")
                    print(f"\nAssistant (Code):\n{assistant_text}\n")
                    logger.info(f"[AutoCodingAgent] Completed in {time.time()-start_time:.2f}s")
                else:
                    response = proxy_agent.process(user_input)
                    assistant_text = response.get("text", "No response generated")
                    print(f"\nAssistant: {assistant_text}\n")

            except Exception as e:
                print(f"\nAssistant: Error processing request: {e}\n")
                logger.exception(f"Error while processing query: {e}")

            duration = time.time() - start_time
            logger.info(f"🕒 Query processed in {duration:.2f}s")

    except Exception as e:
        logger.exception(f"Assistant failed to start: {e}")
        print(f"❌ Failed to start assistant: {e}")


if __name__ == "__main__":
    main()
